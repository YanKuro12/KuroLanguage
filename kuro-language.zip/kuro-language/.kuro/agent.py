import json
import os
import sys
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from tools.filesystem import Workspace
from tools.cargo import cargo_test

API_URL = "https://openrouter.ai/api/v1/chat/completions"
BASE_DIR = Path(__file__).resolve().parent

def load_env():
    p = BASE_DIR / ".env"
    if not p.exists(): return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line: continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
load_env()
API_KEY = os.getenv("OPENROUTER_API_KEY")
MODEL = os.getenv("OPENROUTER_MODEL", "stealth/ox-alpha")
if not API_KEY: raise SystemExit("OPENROUTER_API_KEY belum diatur. Isi file .env.")

def tool_schema():
    return [
        {"type":"function","function":{"name":"list_dir","description":"List files/directories in the KuroLanguage repository.","parameters":{"type":"object","properties":{"path":{"type":"string"}},"required":["path"]}}},
        {"type":"function","function":{"name":"read_file","description":"Read a UTF-8 text file from the repository.","parameters":{"type":"object","properties":{"path":{"type":"string"}},"required":["path"]}}},
        {"type":"function","function":{"name":"search_files","description":"Search for an exact text substring across repository text files.","parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}}},
        {"type":"function","function":{"name":"write_file","description":"Create or replace a UTF-8 text file. Inspect existing content first when modifying a file.","parameters":{"type":"object","properties":{"path":{"type":"string"},"content":{"type":"string"}},"required":["path","content"]}}},
        {"type":"function","function":{"name":"run_cargo_test","description":"Run exactly cargo test --workspace in the repository.","parameters":{"type":"object","properties":{}}}},
    ]

def api(messages):
    body = {"model":MODEL,"messages":messages,"tools":tool_schema(),"tool_choice":"auto"}
    req = Request(API_URL, data=json.dumps(body).encode(), headers={"Authorization":f"Bearer {API_KEY}","Content-Type":"application/json","X-Title":"KuroLanguage Agent"}, method="POST")
    try:
        with urlopen(req, timeout=180) as r: return json.loads(r.read().decode())
    except HTTPError as e: raise RuntimeError(f"OpenRouter HTTP {e.code}: {e.read().decode(errors='replace')}")
    except URLError as e: raise RuntimeError(f"Network error: {e.reason}")

def execute(ws, name, args):
    try:
        if name == "list_dir": return ws.list_dir(args["path"])
        if name == "read_file": return ws.read_file(args["path"])
        if name == "search_files": return ws.search_files(args["query"])
        if name == "write_file":
            print(f"\n[write_file] {args['path']}")
            if input("Allow write? [y/N] ").strip().lower() != "y": return {"success":False,"error":"User denied write_file."}
            return ws.write_file(args["path"], args["content"])
        if name == "run_cargo_test":
            print("\n[cargo] cargo test --workspace")
            return cargo_test(ws.root)
        return {"error":f"Unknown tool: {name}"}
    except Exception as e: return {"error":str(e)}

def run(messages, ws):
    for _ in range(30):
        response = api(messages)
        message = response["choices"][0]["message"]
        calls = message.get("tool_calls", [])
        if not calls: return message.get("content") or "(no response)"
        messages.append(message)
        for call in calls:
            fn = call["function"]
            args = json.loads(fn.get("arguments", "{}"))
            result = execute(ws, fn["name"], args)
            messages.append({"role":"tool","tool_call_id":call["id"],"content":json.dumps(result,ensure_ascii=False)})
    raise RuntimeError("Tool-call limit reached.")

def main():
    root = sys.argv[1] if len(sys.argv) > 1 else str(BASE_DIR / "workspace")
    ws = Workspace(root)
    prompt = (BASE_DIR / "prompts" / "kurolanguage.txt").read_text(encoding="utf-8")
    messages = [{"role":"system","content":prompt + f"\n\nRepository root: {ws.root}"}]
    print(f"KuroLanguage Agent\nModel: {MODEL}\nRepository: {ws.root}\nType `exit` to quit.\n")
    while True:
        try: user = input("You > ").strip()
        except (EOFError, KeyboardInterrupt): print(); return
        if user.lower() in {"exit","quit"}: return
        if not user: continue
        messages.append({"role":"user","content":user})
        try:
            answer = run(messages, ws)
            messages.append({"role":"assistant","content":answer})
            print(f"\nKuro > {answer}\n")
        except Exception as e: print(f"\nERROR: {e}\n")

if __name__ == "__main__": main()
