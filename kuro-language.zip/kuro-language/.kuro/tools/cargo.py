import subprocess
from pathlib import Path

def cargo_test(workspace: Path):
    result = subprocess.run(
        ["cargo", "test", "--workspace"], cwd=workspace, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=600
    )
    return {"success": result.returncode == 0, "exit_code": result.returncode, "output": result.stdout[-30000:]}
