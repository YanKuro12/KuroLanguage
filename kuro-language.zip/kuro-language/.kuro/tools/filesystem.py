from pathlib import Path

MAX_READ_BYTES = 2 * 1024 * 1024

class Workspace:
    def __init__(self, root: str):
        self.root = Path(root).expanduser().resolve()
        if not self.root.exists():
            raise FileNotFoundError(f"Workspace tidak ditemukan: {self.root}")
        if not self.root.is_dir():
            raise NotADirectoryError(f"Workspace bukan directory: {self.root}")

    def safe(self, relative: str) -> Path:
        p = (self.root / relative).resolve()
        try:
            p.relative_to(self.root)
        except ValueError:
            raise PermissionError("Path berada di luar workspace.")
        return p

    def list_dir(self, path="."):
        p = self.safe(path)
        if not p.is_dir():
            raise NotADirectoryError(path)
        return {"path": path, "entries": [
            {"name": x.name, "type": "directory" if x.is_dir() else "file"}
            for x in sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
        ]}

    def read_file(self, path):
        p = self.safe(path)
        if not p.is_file():
            raise FileNotFoundError(path)
        if p.stat().st_size > MAX_READ_BYTES:
            raise ValueError("File lebih besar dari 2 MB.")
        return {"path": path, "content": p.read_text(encoding="utf-8")}

    def search_files(self, query):
        results = []
        for p in self.root.rglob("*"):
            if not p.is_file() or any(part in {".git", "target", "__pycache__"} for part in p.relative_to(self.root).parts):
                continue
            try:
                text = p.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            if query in text:
                results.append(str(p.relative_to(self.root)))
                if len(results) >= 100:
                    break
        return {"query": query, "files": results}

    def write_file(self, path, content):
        p = self.safe(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return {"success": True, "path": path, "bytes": len(content.encode("utf-8"))}
