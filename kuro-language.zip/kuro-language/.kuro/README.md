# KuroLanguage Agent v1

AI coding agent khusus repository KuroLanguage menggunakan OpenRouter.

## Setup

```bash
cp .env.example .env
nano .env
python agent.py /path/ke/repository/kurolanguage
```

Tools v1: list_dir, read_file, search_files, write_file, run_cargo_test.
Write file selalu meminta konfirmasi. Path dibatasi ke repository. Command execution hanya `cargo test --workspace`.
