use super::{Analyzer, STDLIB_MODULES};
use crate::types::Type;
use kuro_ast::{BinaryOp, Expr, ExprKind, UnaryOp};
use kuro_source::Span;

impl Analyzer {
    pub(super) fn check_expr(&mut self, expr: &Expr) -> Type {
        match &expr.kind {
            ExprKind::IntLiteral(_) => Type::Int,
            ExprKind::FloatLiteral(_) => Type::Float,
            ExprKind::StringLiteral(_) => Type::String,
            ExprKind::BoolLiteral(_) => Type::Bool,
            ExprKind::NullLiteral => Type::Null,
            ExprKind::Ident(name) => self.check_ident(name, expr.span),
            ExprKind::Binary(left, op, right) => self.check_binary(left, *op, right, expr.span),
            ExprKind::Unary(op, operand) => self.check_unary(*op, operand, expr.span),
            ExprKind::Call(callee, args) => self.check_call(callee, args, expr.span),
            ExprKind::Member(object, name) => self.check_member(object, name, expr.span),
        }
    }

    fn check_ident(&mut self, name: &str, span: Span) -> Type {
        match self.lookup(name) {
            Some(ty) => ty,
            None => {
                self.error(format!("Undefined name '{name}'"), span);
                Type::Unknown
            }
        }
    }

    fn check_binary(&mut self, left: &Expr, op: BinaryOp, right: &Expr, span: Span) -> Type {
        let left_ty = self.check_expr(left);
        let right_ty = self.check_expr(right);
        match op {
            BinaryOp::Add | BinaryOp::Sub | BinaryOp::Mul | BinaryOp::Div | BinaryOp::Mod => {
                self.check_numeric_operands(&left_ty, &right_ty, span)
            }
            BinaryOp::Lt | BinaryOp::Gt | BinaryOp::LtEq | BinaryOp::GtEq => {
                self.check_numeric_operands(&left_ty, &right_ty, span);
                Type::Bool
            }
            BinaryOp::Eq | BinaryOp::NotEq => {
                if !left_ty.is_compatible_with(&right_ty) {
                    self.error(format!("Cannot compare {left_ty} with {right_ty}"), span);
                }
                Type::Bool
            }
            BinaryOp::And | BinaryOp::Or => {
                if !left_ty.is_bool() {
                    self.error(format!("Expected Bool, found {left_ty}"), span);
                }
                if !right_ty.is_bool() {
                    self.error(format!("Expected Bool, found {right_ty}"), span);
                }
                Type::Bool
            }
        }
    }

    /// Checks that both operands support `+ - * / %`, and returns the
    /// result type: `Float` if either operand is `Float`, otherwise
    /// `Int`. Errors on either side don't prevent the other from also
    /// being checked, so both get reported in one pass if both are wrong.
    fn check_numeric_operands(&mut self, left: &Type, right: &Type, span: Span) -> Type {
        let left_ok = left.is_numeric();
        let right_ok = right.is_numeric();
        if !left_ok {
            self.error(format!("Expected a numeric value, found {left}"), span);
        }
        if !right_ok {
            self.error(format!("Expected a numeric value, found {right}"), span);
        }
        if !left_ok || !right_ok {
            return Type::Unknown;
        }
        if *left == Type::Unknown || *right == Type::Unknown {
            return Type::Unknown;
        }
        if *left == Type::StdlibUnknown || *right == Type::StdlibUnknown {
            return Type::StdlibUnknown;
        }
        if *left == Type::Float || *right == Type::Float {
            Type::Float
        } else {
            Type::Int
        }
    }

    fn check_unary(&mut self, op: UnaryOp, operand: &Expr, span: Span) -> Type {
        let operand_ty = self.check_expr(operand);
        match op {
            UnaryOp::Neg => {
                if !operand_ty.is_numeric() {
                    self.error(
                        format!("Expected a numeric value, found {operand_ty}"),
                        span,
                    );
                    return Type::Unknown;
                }
                operand_ty
            }
            UnaryOp::Not => {
                if !operand_ty.is_bool() {
                    self.error(format!("Expected Bool, found {operand_ty}"), span);
                    return Type::Unknown;
                }
                Type::Bool
            }
        }
    }

    fn check_call(&mut self, callee: &Expr, args: &[Expr], span: Span) -> Type {
        // Every argument is checked regardless of what the callee turns
        // out to be, so a mistake in an argument is still reported even
        // if the callee itself isn't callable.
        let mut arg_types = Vec::with_capacity(args.len());
        for arg in args {
            arg_types.push(self.check_expr(arg));
        }

        if let ExprKind::Ident(name) = &callee.kind {
            return self.check_function_call(name, &arg_types, callee.span, span);
        }

        if let ExprKind::Member(object, _member_name) = &callee.kind {
            let object_ty = self.check_expr(object);
            if matches!(object_ty, Type::StdlibUnknown | Type::Unknown) {
                return Type::StdlibUnknown;
            }
            self.error(
                format!("'{object_ty}' has no callable members"),
                callee.span,
            );
            return Type::Unknown;
        }

        self.error(
            "This expression can't be called like a function",
            callee.span,
        );
        Type::Unknown
    }

    /// Resolves a call whose callee is a bare name: a stdlib module used
    /// without a member (treated leniently, like any other stdlib use), a
    /// user-defined function (checked against its collected signature),
    /// or an undefined name.
    fn check_function_call(
        &mut self,
        name: &str,
        arg_types: &[Type],
        callee_span: Span,
        call_span: Span,
    ) -> Type {
        if STDLIB_MODULES.contains(&name) {
            return Type::StdlibUnknown;
        }
        let signature = self.lookup_function(name).cloned();
        let signature = match signature {
            Some(sig) => sig,
            None => {
                self.error(format!("Undefined function '{name}'"), callee_span);
                return Type::Unknown;
            }
        };
        if signature.param_types.len() != arg_types.len() {
            self.error(
                format!(
                    "'{name}' expects {} argument(s), found {}",
                    signature.param_types.len(),
                    arg_types.len()
                ),
                call_span,
            );
            return signature.return_type.unwrap_or(Type::Void);
        }
        for (i, (param_ty, arg_ty)) in signature
            .param_types
            .iter()
            .zip(arg_types.iter())
            .enumerate()
        {
            if !param_ty.is_compatible_with(arg_ty) {
                self.error(
                    format!(
                        "Argument {} to '{name}': expected {param_ty}, found {arg_ty}",
                        i + 1
                    ),
                    call_span,
                );
            }
        }
        signature.return_type.unwrap_or(Type::Void)
    }

    /// A member access not used as a call, e.g. `Console.Print` on its
    /// own. The member name itself isn't checked against anything yet —
    /// see [`Type::StdlibUnknown`] — only that the object it's accessed
    /// on is something members are recognized on at all.
    fn check_member(&mut self, object: &Expr, _name: &str, span: Span) -> Type {
        let object_ty = self.check_expr(object);
        if matches!(object_ty, Type::StdlibUnknown | Type::Unknown) {
            return Type::StdlibUnknown;
        }
        self.error(
            format!("'{object_ty}' has no members — only standard library modules do right now"),
            span,
        );
        Type::Unknown
    }
}
