use super::{Analyzer, STDLIB_MODULES};
use crate::types::Type;
use kuro_ast::{Block, ElseBranch, Expr, ExprKind, IfStmt, ReturnStmt, Stmt};

impl Analyzer {
    pub(super) fn check_block(&mut self, block: &Block) {
        self.push_scope();
        for stmt in &block.statements {
            self.check_stmt(stmt);
        }
        self.pop_scope();
    }

    fn check_stmt(&mut self, stmt: &Stmt) {
        match stmt {
            Stmt::VarDecl(var) => {
                let value_ty = self.check_expr(&var.value);
                let declared_ty = match &var.type_annotation {
                    Some(annotation) => Some(self.resolve_type_annotation(annotation)),
                    None => None,
                };
                let final_ty = match declared_ty {
                    Some(declared) => {
                        if !declared.is_compatible_with(&value_ty) {
                            self.error(
                                format!(
                                    "'{}' is declared as {declared} but given {value_ty}",
                                    var.name
                                ),
                                var.span,
                            );
                        }
                        declared
                    }
                    None => value_ty,
                };
                self.declare(&var.name, final_ty, true, var.span);
            }
            Stmt::ConstDecl(c) => {
                let value_ty = self.check_expr(&c.value);
                self.declare(&c.name, value_ty, false, c.span);
            }
            Stmt::Assign(assign) => {
                let target_ty = self.check_assignment_target(&assign.target);
                let value_ty = self.check_expr(&assign.value);
                if let Some(target_ty) = target_ty {
                    if !target_ty.is_compatible_with(&value_ty) {
                        self.error(
                            format!("Cannot assign {value_ty} to a variable of type {target_ty}"),
                            assign.span,
                        );
                    }
                }
            }
            Stmt::Expr(expr_stmt) => {
                self.check_expr(&expr_stmt.expr);
            }
            Stmt::If(if_stmt) => self.check_if_stmt(if_stmt),
            Stmt::While(w) => {
                let cond_ty = self.check_expr(&w.condition);
                if !cond_ty.is_bool() {
                    self.error(format!("Expected Bool, found {cond_ty}"), w.condition.span);
                }
                self.loop_depth += 1;
                self.check_block(&w.body);
                self.loop_depth -= 1;
            }
            Stmt::For(f) => {
                let start_ty = self.check_expr(&f.start);
                if !start_ty.is_numeric() {
                    self.error(
                        format!("Expected a numeric value, found {start_ty}"),
                        f.start.span,
                    );
                }
                let end_ty = self.check_expr(&f.end);
                if !end_ty.is_numeric() {
                    self.error(
                        format!("Expected a numeric value, found {end_ty}"),
                        f.end.span,
                    );
                }
                self.push_scope();
                self.declare(&f.binding, Type::Int, true, f.span);
                self.loop_depth += 1;
                self.check_block(&f.body);
                self.loop_depth -= 1;
                self.pop_scope();
            }
            Stmt::Foreach(f) => {
                // No collection/array type exists yet in kuro_ast, so the
                // iterable can't be checked against anything specific —
                // just confirm it's a valid expression, and give the
                // binding an Unknown type rather than guessing at an
                // element type that isn't defined anywhere yet.
                self.check_expr(&f.iterable);
                self.push_scope();
                self.declare(&f.binding, Type::Unknown, true, f.span);
                self.loop_depth += 1;
                self.check_block(&f.body);
                self.loop_depth -= 1;
                self.pop_scope();
            }
            Stmt::Return(ret) => self.check_return_stmt(ret),
            Stmt::Break(span) => {
                if self.loop_depth == 0 {
                    self.error("'Break' used outside of a loop", *span);
                }
            }
            Stmt::Continue(span) => {
                if self.loop_depth == 0 {
                    self.error("'Continue' used outside of a loop", *span);
                }
            }
            Stmt::Block(block) => self.check_block(block),
        }
    }

    fn check_if_stmt(&mut self, if_stmt: &IfStmt) {
        let cond_ty = self.check_expr(&if_stmt.condition);
        if !cond_ty.is_bool() {
            self.error(
                format!("Expected Bool, found {cond_ty}"),
                if_stmt.condition.span,
            );
        }
        self.check_block(&if_stmt.then_branch);
        match &if_stmt.else_branch {
            Some(ElseBranch::ElseIf(nested)) => self.check_if_stmt(nested),
            Some(ElseBranch::Else(block)) => self.check_block(block),
            None => {}
        }
    }

    fn check_return_stmt(&mut self, ret: &ReturnStmt) {
        // Cloned out first so the match below is on an owned value, not a
        // borrow of `self` — keeps the arms free to check expressions and
        // report errors on `self` without any borrow overlap to reason
        // about.
        let expected = self.current_return_type.clone();
        match (expected, &ret.value) {
            (Some(expected), Some(value)) => {
                let value_ty = self.check_expr(value);
                if !expected.is_compatible_with(&value_ty) {
                    self.error(
                        format!("Expected to return {expected}, found {value_ty}"),
                        value.span,
                    );
                }
            }
            (Some(expected), None) => {
                self.error(
                    format!("Expected to return a value of type {expected}"),
                    ret.span,
                );
            }
            (None, Some(value)) => {
                self.check_expr(value);
                self.error(
                    "This function has no return type, so it can't return a value",
                    ret.span,
                );
            }
            (None, None) => {}
        }
    }

    /// Resolves what an assignment's left-hand side refers to, so its
    /// current type can be checked against the right-hand side — and
    /// rejects the assignment outright if it targets a `Const`. Only a
    /// bare identifier is meaningful right now — `AssignStmt::target`
    /// being a full `Expr` already allows for member/index targets once
    /// there's a type with members or an array type to assign into.
    fn check_assignment_target(&mut self, target: &Expr) -> Option<Type> {
        if let ExprKind::Ident(name) = &target.kind {
            // Looked up as an owned value first (rather than matching
            // directly on a borrow of `self.scopes`) so the branches
            // below are free to report errors on `self` without any
            // borrow of it still active.
            if let Some(binding) = self.find_local_binding(name) {
                if !binding.mutable {
                    self.error(format!("Cannot assign to '{name}': it's a Const"), target.span);
                    return None;
                }
                return Some(binding.ty);
            }
            if self.globals.contains_key(name) {
                self.error(format!("Cannot assign to '{name}': it's a Const"), target.span);
                return None;
            }
            if STDLIB_MODULES.contains(&name.as_str()) {
                self.error(
                    format!("Cannot assign to '{name}': it's a standard library name"),
                    target.span,
                );
                return None;
            }
            self.error(format!("Undefined name '{name}'"), target.span);
            return None;
        }
        self.error(
            "Only a plain variable name can be assigned to right now",
            target.span,
        );
        None
    }
}
