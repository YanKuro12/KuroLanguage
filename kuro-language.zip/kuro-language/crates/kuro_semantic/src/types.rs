use std::fmt;

/// A KuroLanguage type, as understood by semantic analysis.
///
/// This only covers what's needed to check the language surface confirmed
/// so far. There's no array/collection type yet (no such literal exists in
/// `kuro_ast`), and no user-defined types (structs, enums) exist yet
/// either — both are additive whenever they're confirmed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Type {
    Int,
    Float,
    String,
    Bool,
    /// The type of the `null` literal. For now `null` only matches
    /// itself — there's no nullable/optional form of the other types yet,
    /// since none has been specified. A variable holding `null` currently
    /// can't be reassigned a `String`/`Int`/etc. without a type error.
    Null,
    /// A function that declares no return type, e.g. `Func Main() { }`.
    /// Such a function can't be used as a value, and can't `Return value`
    /// (only a bare `Return` or falling off the end).
    Void,
    /// Stands in for a stdlib member whose real signature isn't known yet
    /// — no `kuro_stdlib` crate exists at this point in the pipeline.
    /// Compatible with anything, so a call like `Console.Print(...)`
    /// doesn't get type errors this crate has no real basis to report.
    StdlibUnknown,
    /// Stands in for an expression that already produced an error.
    /// Compatible with anything, so one mistake doesn't cascade into a
    /// wall of further, misleading errors around it.
    Unknown,
}

impl Type {
    /// Whether a value of type `other` may be used where `self` is
    /// expected — e.g. a `Var`/`Const` value against its declared type,
    /// or a call argument against its parameter type.
    pub fn is_compatible_with(&self, other: &Type) -> bool {
        if self.is_placeholder() || other.is_placeholder() {
            return true;
        }
        self == other
    }

    pub fn is_numeric(&self) -> bool {
        matches!(self, Type::Int | Type::Float) || self.is_placeholder()
    }

    pub fn is_bool(&self) -> bool {
        matches!(self, Type::Bool) || self.is_placeholder()
    }

    fn is_placeholder(&self) -> bool {
        matches!(self, Type::Unknown | Type::StdlibUnknown)
    }
}

impl fmt::Display for Type {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let name = match self {
            Type::Int => "Int",
            Type::Float => "Float",
            Type::String => "String",
            Type::Bool => "Bool",
            Type::Null => "null",
            Type::Void => "Void",
            Type::StdlibUnknown | Type::Unknown => "<unknown>",
        };
        f.write_str(name)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn unknown_is_compatible_with_everything() {
        assert!(Type::Unknown.is_compatible_with(&Type::Int));
        assert!(Type::Int.is_compatible_with(&Type::Unknown));
        assert!(Type::StdlibUnknown.is_compatible_with(&Type::String));
    }

    #[test]
    fn mismatched_concrete_types_are_incompatible() {
        assert!(!Type::Int.is_compatible_with(&Type::String));
        assert!(!Type::Bool.is_compatible_with(&Type::Float));
    }

    #[test]
    fn same_concrete_type_is_compatible() {
        assert!(Type::Int.is_compatible_with(&Type::Int));
    }
}
