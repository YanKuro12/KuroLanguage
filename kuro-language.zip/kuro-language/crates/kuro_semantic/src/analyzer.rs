use crate::types::Type;
use kuro_ast::{FunctionDecl, Item, Program, TypeAnnotation};
use kuro_diagnostics::{Diagnostic, Diagnostics};
use kuro_source::Span;
use std::collections::HashMap;

mod expr;
mod stmt;

/// A user-defined function's signature, collected in a first pass so
/// calls resolve regardless of where the function is declared in the
/// file.
#[derive(Debug, Clone)]
pub(crate) struct FunctionSignature {
    pub param_types: Vec<Type>,
    pub return_type: Option<Type>,
}

/// A named local value: its type, and whether it can be reassigned.
/// `Var` and function parameters are mutable; `Const` is not — that's
/// the entire point of `Const`, so assigning to one is a semantic error
/// (see [`Analyzer::check_assignment_target`]). Top-level `Const`s don't
/// need this: everything in `globals` is already immutable by
/// construction, since only `Const` populates it.
#[derive(Debug, Clone)]
pub(crate) struct Binding {
    pub ty: Type,
    pub mutable: bool,
}

/// Names recognized as standard library modules, e.g. `Console` in
/// `Console.Print(...)`. Their members aren't type-checked in detail yet
/// (see [`Type::StdlibUnknown`]) since no `kuro_stdlib` crate exists yet
/// at this point in the pipeline for their real signatures to come from.
/// A user declaring a function/const/variable with one of these names is
/// treated as a conflict (see [`Analyzer::is_name_taken`]), consistent
/// with these being effectively-reserved even though the lexer doesn't
/// reserve them as keywords.
const STDLIB_MODULES: &[&str] = &[
    "Console",
    "Convert",
    "Math",
    "String",
    "Random",
    "Date",
    "Json",
    "Regex",
    "Encoding",
    "Collection",
    "Network",
    "HTTP",
    "Filesystem",
];

/// Checks a parsed [`Program`] for name and type errors.
///
/// Construct with [`Analyzer::new`], then call [`Analyzer::analyze`].
/// Like the lexer and parser before it, checking never stops at the first
/// problem: every mistake found is recorded as a [`Diagnostic`] and
/// checking continues, so one run can surface everything wrong with a
/// program at once. [`Type::Unknown`] is what makes this safe — once part
/// of an expression has an error, it stops contributing further ones.
#[derive(Debug, Default)]
pub struct Analyzer {
    functions: HashMap<String, FunctionSignature>,
    globals: HashMap<String, Type>,
    scopes: Vec<HashMap<String, Binding>>,
    loop_depth: u32,
    /// The enclosing function's declared return type while checking its
    /// body — `None` covers both "not currently in a function" and "in a
    /// function with no declared return type"; the two never need telling
    /// apart, since only function bodies are checked with this set.
    current_return_type: Option<Type>,
    diagnostics: Diagnostics,
}

impl Analyzer {
    pub fn new() -> Self {
        Self::default()
    }

    /// Checks the whole program in three passes:
    /// 1. Collect every function's signature.
    /// 2. Check every top-level `Const` value, in file order (so one can
    ///    reference an earlier one).
    /// 3. Check every function body — by now able to see all functions
    ///    and all top-level consts, regardless of their order in the
    ///    file.
    pub fn analyze(mut self, program: &Program) -> Diagnostics {
        self.collect_function_signatures(program);
        self.check_top_level_consts(program);
        self.check_function_bodies(program);
        self.diagnostics
    }

    fn collect_function_signatures(&mut self, program: &Program) {
        for item in &program.items {
            if let Item::Function(func) = item {
                if self.is_name_taken(&func.name) {
                    self.error(format!("'{}' is already declared", func.name), func.span);
                    continue;
                }
                let mut param_types = Vec::with_capacity(func.params.len());
                for param in &func.params {
                    param_types.push(self.resolve_type_annotation(&param.type_annotation));
                }
                let return_type = match &func.return_type {
                    Some(annotation) => Some(self.resolve_type_annotation(annotation)),
                    None => None,
                };
                self.functions.insert(
                    func.name.clone(),
                    FunctionSignature {
                        param_types,
                        return_type,
                    },
                );
            }
        }
    }

    fn check_top_level_consts(&mut self, program: &Program) {
        for item in &program.items {
            if let Item::Const(c) = item {
                if self.is_name_taken(&c.name) {
                    self.error(format!("'{}' is already declared", c.name), c.span);
                    continue;
                }
                let value_type = self.check_expr(&c.value);
                self.globals.insert(c.name.clone(), value_type);
            }
        }
    }

    fn check_function_bodies(&mut self, program: &Program) {
        for item in &program.items {
            if let Item::Function(func) = item {
                self.check_function_body(func);
            }
        }
    }

    fn check_function_body(&mut self, func: &FunctionDecl) {
        let return_type = match &func.return_type {
            Some(annotation) => Some(self.resolve_type_annotation(annotation)),
            None => None,
        };
        self.current_return_type = return_type;
        self.push_scope();
        for param in &func.params {
            let ty = self.resolve_type_annotation(&param.type_annotation);
            self.declare(&param.name, ty, true, param.span);
        }
        self.check_block(&func.body);
        self.pop_scope();
        self.current_return_type = None;
    }

    fn is_name_taken(&self, name: &str) -> bool {
        self.functions.contains_key(name)
            || self.globals.contains_key(name)
            || STDLIB_MODULES.contains(&name)
    }

    /// Resolves a written type name (`Int`, `Float`, ...) to a [`Type`].
    /// An unrecognized name is reported and treated as [`Type::Unknown`]
    /// so checking can continue without cascading.
    fn resolve_type_annotation(&mut self, annotation: &TypeAnnotation) -> Type {
        match annotation.name.as_str() {
            "Int" => Type::Int,
            "Float" => Type::Float,
            "String" => Type::String,
            "Bool" => Type::Bool,
            other => {
                self.error(format!("Unknown type '{other}'"), annotation.span);
                Type::Unknown
            }
        }
    }

    // --- scope management ----------------------------------------------

    fn push_scope(&mut self) {
        self.scopes.push(HashMap::new());
    }

    fn pop_scope(&mut self) {
        self.scopes.pop();
    }

    /// Declares `name` in the innermost scope as mutable (`Var`, function
    /// parameters, loop bindings) or not (`Const`). A nested scope may
    /// still shadow an outer one — that check is skipped here entirely,
    /// since only the innermost scope is inspected — but redeclaring
    /// within the same scope, or reusing a stdlib module name, is
    /// reported instead.
    fn declare(&mut self, name: &str, ty: Type, mutable: bool, span: Span) {
        if STDLIB_MODULES.contains(&name) {
            self.error(
                format!("'{name}' is a standard library name and can't be redeclared"),
                span,
            );
            return;
        }
        let already_in_this_scope = self
            .scopes
            .last()
            .map(|scope| scope.contains_key(name))
            .unwrap_or(false);
        if already_in_this_scope {
            self.error(format!("'{name}' is already declared in this scope"), span);
            return;
        }
        if let Some(scope) = self.scopes.last_mut() {
            scope.insert(name.to_string(), Binding { ty, mutable });
        }
    }

    /// Looks up `name`: innermost scope outward, then top-level consts,
    /// then whether it's a recognized stdlib module name. Returns `None`
    /// if nothing matches — the caller reports "undefined name", since
    /// only it knows the right span to attach.
    fn lookup(&self, name: &str) -> Option<Type> {
        for scope in self.scopes.iter().rev() {
            if let Some(binding) = scope.get(name) {
                return Some(binding.ty.clone());
            }
        }
        if let Some(ty) = self.globals.get(name) {
            return Some(ty.clone());
        }
        if STDLIB_MODULES.contains(&name) {
            return Some(Type::StdlibUnknown);
        }
        None
    }

    /// Looks up `name` in the local scope stack only (not top-level
    /// consts or stdlib modules), returning an owned clone so callers are
    /// free to report errors on `self` afterward with no borrow left
    /// active — see [`Self::check_assignment_target`], the one caller
    /// that needs the mutability flag this carries.
    fn find_local_binding(&self, name: &str) -> Option<Binding> {
        for scope in self.scopes.iter().rev() {
            if let Some(binding) = scope.get(name) {
                return Some(binding.clone());
            }
        }
        None
    }

    fn lookup_function(&self, name: &str) -> Option<&FunctionSignature> {
        self.functions.get(name)
    }

    // --- diagnostics -----------------------------------------------------

    fn error(&mut self, message: impl Into<String>, span: Span) {
        self.diagnostics.push(Diagnostic::error(message, span));
    }
}
