//! Semantic analysis for KuroLanguage: name resolution and type checking
//! over a parsed [`kuro_ast::Program`].
//!
//! This crate depends only on `kuro_ast` for the tree it walks, and on
//! `kuro_source`/`kuro_diagnostics` for reporting problems — not on
//! `kuro_lexer` or `kuro_parser` (those are only pulled in as
//! dev-dependencies, for this crate's own tests). This matches the
//! pipeline direction: Lexer → AST → Parser → Semantic Analysis.

mod analyzer;
mod types;

pub use analyzer::Analyzer;
pub use types::Type;

use kuro_ast::Program;
use kuro_diagnostics::Diagnostics;

/// Checks a [`Program`] for name and type errors. A convenience wrapper
/// around [`Analyzer::new`] and [`Analyzer::analyze`].
pub fn analyze(program: &Program) -> Diagnostics {
    Analyzer::new().analyze(program)
}

#[cfg(test)]
mod tests {
    use super::*;
    use kuro_lexer::Lexer;
    use kuro_source::SourceMap;

    /// Lexes, parses, then semantically analyzes `src`, asserting neither
    /// the lexer nor the parser produced errors — a bug in either would
    /// otherwise masquerade as a semantic one.
    fn analyze_source(src: &str) -> Diagnostics {
        let mut sources = SourceMap::new();
        let id = sources.add_file("test.kr", src);
        let (tokens, lex_diagnostics) = Lexer::new(id, src).tokenize();
        assert!(
            lex_diagnostics.is_empty(),
            "unexpected lexer errors: {lex_diagnostics:?}"
        );
        let (program, parse_diagnostics) = kuro_parser::parse(&tokens);
        assert!(
            parse_diagnostics.is_empty(),
            "unexpected parser errors: {parse_diagnostics:?}"
        );
        analyze(&program)
    }

    #[test]
    fn accepts_a_well_typed_program() {
        let diagnostics = analyze_source(
            "Func Add(a Int, b Int) Int {\n    Return a + b\n}\nFunc Main() {\n    Var x = Add(1, 2)\n}",
        );
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
    }

    #[test]
    fn accepts_stdlib_calls_leniently() {
        let diagnostics =
            analyze_source("Func Main() {\n    Console.Print(\"hi\")\n    Console.PrintLine(123)\n}");
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
    }

    #[test]
    fn catches_type_mismatch_on_reassignment() {
        let diagnostics = analyze_source("Func Main() {\n    Var x = 1\n    x = \"oops\"\n}");
        assert!(diagnostics.has_errors());
    }

    #[test]
    fn catches_undefined_name() {
        let diagnostics = analyze_source("Func Main() {\n    Console.Print(y)\n}");
        assert!(diagnostics.has_errors());
    }

    #[test]
    fn undefined_name_does_not_cascade_into_further_errors() {
        // `y` is undefined; the `+ 1` around it shouldn't add a second,
        // misleading "expected a numeric value" error on top of that.
        let diagnostics = analyze_source("Func Main() {\n    Var x = y + 1\n}");
        assert_eq!(diagnostics.len(), 1, "{diagnostics:?}");
    }

    #[test]
    fn catches_wrong_argument_count() {
        let diagnostics = analyze_source(
            "Func Add(a Int, b Int) Int {\n    Return a + b\n}\nFunc Main() {\n    Var x = Add(1)\n}",
        );
        assert!(diagnostics.has_errors());
    }

    #[test]
    fn catches_wrong_argument_type() {
        let diagnostics = analyze_source(
            "Func Add(a Int, b Int) Int {\n    Return a + b\n}\nFunc Main() {\n    Var x = Add(1, \"two\")\n}",
        );
        assert!(diagnostics.has_errors());
    }

    #[test]
    fn catches_break_outside_loop() {
        let diagnostics = analyze_source("Func Main() {\n    Break\n}");
        assert!(diagnostics.has_errors());
    }

    #[test]
    fn accepts_break_inside_loop() {
        let diagnostics = analyze_source("Func Main() {\n    While true {\n        Break\n    }\n}");
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
    }

    #[test]
    fn catches_duplicate_function_declaration() {
        let diagnostics = analyze_source("Func Main() {\n}\nFunc Main() {\n}");
        assert!(diagnostics.has_errors());
    }

    #[test]
    fn catches_return_value_in_void_function() {
        let diagnostics = analyze_source("Func Main() {\n    Return 1\n}");
        assert!(diagnostics.has_errors());
    }

    #[test]
    fn allows_forward_reference_between_functions() {
        // Main calls Helper, declared afterward — fine, since every
        // function's signature is collected before any body is checked.
        let diagnostics = analyze_source("Func Main() {\n    Helper()\n}\nFunc Helper() {\n}");
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
    }

    #[test]
    fn allows_shadowing_in_a_nested_block() {
        let diagnostics = analyze_source(
            "Func Main() {\n    Var x = 1\n    {\n        Var x = \"shadowed\"\n    }\n}",
        );
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
    }

    #[test]
    fn catches_redeclaration_in_the_same_scope() {
        let diagnostics = analyze_source("Func Main() {\n    Var x = 1\n    Var x = 2\n}");
        assert!(diagnostics.has_errors());
    }

    #[test]
    fn catches_assignment_to_const() {
        let diagnostics = analyze_source("Func Main() {\n    Const x = 1\n    x = 2\n}");
        assert!(diagnostics.has_errors());
    }

    #[test]
    fn catches_for_loop_bound_of_wrong_type() {
        let diagnostics =
            analyze_source("Func Main() {\n    For i = \"a\" To 10 {\n    }\n}");
        assert!(diagnostics.has_errors());
    }
}
