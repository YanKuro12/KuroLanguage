//! Turns a KuroLanguage token stream into an AST ([`kuro_ast::Program`]).
//!
//! This is the only crate that depends on both `kuro_lexer` and
//! `kuro_ast` — neither of those depends on the other, so this crate is
//! exactly where the two connect, matching the pipeline direction
//! (Lexer → AST → Parser).

mod parser;

pub use parser::Parser;

use kuro_ast::Program;
use kuro_diagnostics::Diagnostics;
use kuro_lexer::Token;

/// Parses a full token stream (as produced by [`kuro_lexer::Lexer`]) into a
/// [`Program`]. A convenience wrapper around [`Parser::new`] and
/// [`Parser::parse_program`] for the common case of parsing a whole file.
pub fn parse(tokens: &[Token]) -> (Program, Diagnostics) {
    Parser::new(tokens).parse_program()
}

#[cfg(test)]
mod tests {
    use super::*;
    use kuro_ast::*;
    use kuro_lexer::Lexer;
    use kuro_source::SourceMap;

    /// Lexes then parses `src`, asserting the lexer itself produced no
    /// errors (a lexer bug would otherwise masquerade as a parser one).
    fn parse_source(src: &str) -> (Program, Diagnostics) {
        let mut sources = SourceMap::new();
        let id = sources.add_file("test.kr", src);
        let (tokens, lex_diagnostics) = Lexer::new(id, src).tokenize();
        assert!(
            lex_diagnostics.is_empty(),
            "unexpected lexer errors: {lex_diagnostics:?}"
        );
        parse(&tokens)
    }

    #[test]
    fn parses_simple_function() {
        let (program, diagnostics) = parse_source("Func Main() {\n    Var x = 1\n}");
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
        assert_eq!(program.items.len(), 1);
        match &program.items[0] {
            Item::Function(func) => {
                assert_eq!(func.name, "Main");
                assert!(func.params.is_empty());
                assert!(func.return_type.is_none());
                assert_eq!(func.body.statements.len(), 1);
                match &func.body.statements[0] {
                    Stmt::VarDecl(var) => {
                        assert_eq!(var.name, "x");
                        assert_eq!(var.value.kind, ExprKind::IntLiteral(1));
                    }
                    other => panic!("expected a Var declaration, got {other:?}"),
                }
            }
            Item::Const(_) => panic!("expected a function item"),
        }
    }

    #[test]
    fn parses_params_and_return_type() {
        // Func Add(a Int, b Int) Int { Return a + b }
        let (program, diagnostics) =
            parse_source("Func Add(a Int, b Int) Int {\n    Return a + b\n}");
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
        match &program.items[0] {
            Item::Function(func) => {
                assert_eq!(func.params.len(), 2);
                assert_eq!(func.params[0].name, "a");
                assert_eq!(func.params[0].type_annotation.name, "Int");
                assert_eq!(func.params[1].name, "b");
                assert_eq!(func.params[1].type_annotation.name, "Int");
                assert_eq!(func.return_type.as_ref().map(|t| t.name.as_str()), Some("Int"));
                match &func.body.statements[0] {
                    Stmt::Return(ret) => {
                        let value = ret.value.as_ref().expect("expected a return value");
                        match &value.kind {
                            ExprKind::Binary(_, BinaryOp::Add, _) => {}
                            other => panic!("expected Add, got {other:?}"),
                        }
                    }
                    other => panic!("expected a Return statement, got {other:?}"),
                }
            }
            Item::Const(_) => panic!("expected a function item"),
        }
    }

    #[test]
    fn respects_operator_precedence() {
        // 1 + 2 * 3 should parse as 1 + (2 * 3), not (1 + 2) * 3.
        let (program, diagnostics) = parse_source("Func Main() {\n    Var x = 1 + 2 * 3\n}");
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
        let Item::Function(func) = &program.items[0] else {
            panic!("expected a function item");
        };
        let Stmt::VarDecl(var) = &func.body.statements[0] else {
            panic!("expected a Var declaration");
        };
        match &var.value.kind {
            ExprKind::Binary(left, BinaryOp::Add, right) => {
                assert_eq!(left.kind, ExprKind::IntLiteral(1));
                match &right.kind {
                    ExprKind::Binary(l, BinaryOp::Mul, r) => {
                        assert_eq!(l.kind, ExprKind::IntLiteral(2));
                        assert_eq!(r.kind, ExprKind::IntLiteral(3));
                    }
                    other => panic!("expected Mul on the right, got {other:?}"),
                }
            }
            other => panic!("expected Add at the top, got {other:?}"),
        }
    }

    #[test]
    fn parses_member_call() {
        // Console.Print("hi")
        let (program, diagnostics) = parse_source("Func Main() {\n    Console.Print(\"hi\")\n}");
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
        let Item::Function(func) = &program.items[0] else {
            panic!("expected a function item");
        };
        match &func.body.statements[0] {
            Stmt::Expr(stmt) => match &stmt.expr.kind {
                ExprKind::Call(callee, args) => {
                    assert_eq!(args.len(), 1);
                    match &callee.kind {
                        ExprKind::Member(object, name) => {
                            assert_eq!(name, "Print");
                            assert_eq!(object.kind, ExprKind::Ident("Console".to_string()));
                        }
                        other => panic!("expected Member, got {other:?}"),
                    }
                }
                other => panic!("expected Call, got {other:?}"),
            },
            other => panic!("expected an expression statement, got {other:?}"),
        }
    }

    #[test]
    fn parses_if_else_if_else_chain() {
        let src = "Func Main() {\n    If x == 1 {\n        Return 1\n    } Else If x == 2 {\n        Return 2\n    } Else {\n        Return 0\n    }\n}";
        let (program, diagnostics) = parse_source(src);
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
        let Item::Function(func) = &program.items[0] else {
            panic!("expected a function item");
        };
        match &func.body.statements[0] {
            Stmt::If(if_stmt) => match &if_stmt.else_branch {
                Some(ElseBranch::ElseIf(nested)) => match &nested.else_branch {
                    Some(ElseBranch::Else(_)) => {}
                    other => panic!("expected a final Else, got {other:?}"),
                },
                other => panic!("expected an Else If, got {other:?}"),
            },
            other => panic!("expected an If statement, got {other:?}"),
        }
    }

    #[test]
    fn parses_while_loop() {
        let (program, diagnostics) = parse_source("Func Main() {\n    While x < 10 {\n        x = x + 1\n    }\n}");
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
        let Item::Function(func) = &program.items[0] else {
            panic!("expected a function item");
        };
        match &func.body.statements[0] {
            Stmt::While(w) => {
                assert_eq!(w.body.statements.len(), 1);
                match &w.body.statements[0] {
                    Stmt::Assign(_) => {}
                    other => panic!("expected an Assign statement, got {other:?}"),
                }
            }
            other => panic!("expected a While statement, got {other:?}"),
        }
    }

    #[test]
    fn parses_for_loop_counting_form() {
        let (program, diagnostics) =
            parse_source("Func Main() {\n    For i = 0 To 10 {\n        Continue\n    }\n}");
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
        let Item::Function(func) = &program.items[0] else {
            panic!("expected a function item");
        };
        match &func.body.statements[0] {
            Stmt::For(f) => {
                assert_eq!(f.binding, "i");
                assert_eq!(f.start.kind, ExprKind::IntLiteral(0));
                assert_eq!(f.end.kind, ExprKind::IntLiteral(10));
            }
            other => panic!("expected a For statement, got {other:?}"),
        }
    }

    #[test]
    fn parses_foreach_loop() {
        let (program, diagnostics) = parse_source(
            "Func Main() {\n    Foreach item In list {\n        Break\n    }\n}",
        );
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
        let Item::Function(func) = &program.items[0] else {
            panic!("expected a function item");
        };
        match &func.body.statements[0] {
            Stmt::Foreach(f) => {
                assert_eq!(f.binding, "item");
                assert_eq!(f.iterable.kind, ExprKind::Ident("list".to_string()));
            }
            other => panic!("expected a Foreach statement, got {other:?}"),
        }
    }

    #[test]
    fn parses_top_level_const() {
        let (program, diagnostics) = parse_source("Const Pi = 3.14");
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
        assert_eq!(program.items.len(), 1);
        match &program.items[0] {
            Item::Const(c) => {
                assert_eq!(c.name, "Pi");
                assert_eq!(c.value.kind, ExprKind::FloatLiteral(3.14));
            }
            Item::Function(_) => panic!("expected a const item"),
        }
    }

    #[test]
    fn multiline_call_across_newlines_still_parses() {
        // Newlines inside ( ) shouldn't break the call.
        let src = "Func Main() {\n    Console.Print(\n        \"hi\"\n    )\n}";
        let (program, diagnostics) = parse_source(src);
        assert!(diagnostics.is_empty(), "{diagnostics:?}");
        let Item::Function(func) = &program.items[0] else {
            panic!("expected a function item");
        };
        assert_eq!(func.body.statements.len(), 1);
    }

    #[test]
    fn error_recovery_reports_and_continues_to_next_item() {
        // The first function is malformed (missing '='); the second one
        // should still parse cleanly, and the diagnostic should mention
        // the problem rather than the parser just giving up.
        let src = "Func Broken() {\n    Var x\n}\nFunc Main() {\n    Var y = 2\n}";
        let (program, diagnostics) = parse_source(src);
        assert!(diagnostics.has_errors());
        assert_eq!(program.items.len(), 2);
        match &program.items[1] {
            Item::Function(func) => assert_eq!(func.name, "Main"),
            Item::Const(_) => panic!("expected the second item to be a function"),
        }
    }
}
