use super::Parser;
use kuro_ast::{ConstDecl, FunctionDecl, Item, Param, TypeAnnotation};
use kuro_lexer::TokenKind;

impl<'a> Parser<'a> {
    /// A top-level item: `Func ...` or `Const ...`. Only these two are
    /// allowed outside a function body (see [`kuro_ast::Item`]).
    pub(super) fn parse_item(&mut self) -> Option<Item> {
        self.skip_newlines();
        // Blank lines (or trailing ones at end of file) land here after
        // being skipped above — `Eof` at this point is normal, not an
        // error, and the caller's loop will stop on its own.
        if self.is_at(&TokenKind::Eof) {
            return None;
        }
        if self.is_at(&TokenKind::Func) {
            return self.parse_function_decl().map(Item::Function);
        }
        if self.is_at(&TokenKind::Const) {
            return self.parse_const_decl().map(Item::Const);
        }
        let span = self.peek().span;
        self.error_with_suggestion(
            "Expected 'Func' or 'Const' at the top level",
            span,
            "Only function and constant declarations are allowed here.",
        );
        None
    }

    fn parse_function_decl(&mut self) -> Option<FunctionDecl> {
        let start_span = self.expect(&TokenKind::Func, "'Func'")?;
        let (name, _) = self.expect_ident()?;
        self.expect(&TokenKind::LParen, "'('")?;
        let params = self.parse_params()?;
        self.expect(&TokenKind::RParen, "')'")?;
        let return_type = self.parse_optional_return_type()?;
        let body = self.parse_block()?;
        let span = start_span.to(body.span);
        Some(FunctionDecl {
            name,
            params,
            return_type,
            body,
            span,
        })
    }

    /// `a Int, b Int` — zero or more `name Type` pairs, comma-separated.
    fn parse_params(&mut self) -> Option<Vec<Param>> {
        let mut params = Vec::new();
        if self.is_at(&TokenKind::RParen) {
            return Some(params);
        }
        loop {
            let (name, name_span) = self.expect_ident()?;
            let type_annotation = self.parse_type_annotation()?;
            let span = name_span.to(type_annotation.span);
            params.push(Param {
                name,
                type_annotation,
                span,
            });
            if self.is_at(&TokenKind::Comma) {
                self.advance();
            } else {
                break;
            }
        }
        Some(params)
    }

    /// A return type is optional: `Func Main() { }` has none, while
    /// `Func Add(a Int, b Int) Int { }` has `Int`. Presence is detected by
    /// checking whether the `{` that starts the body comes next — if not,
    /// whatever's there is taken as the return type name.
    fn parse_optional_return_type(&mut self) -> Option<Option<TypeAnnotation>> {
        if self.is_at(&TokenKind::LBrace) {
            return Some(None);
        }
        self.parse_type_annotation().map(Some)
    }

    /// A type as written in a parameter or return position, e.g. `Int`.
    /// No colon: confirmed as `Func Add(a Int, b Int) Int { }`.
    fn parse_type_annotation(&mut self) -> Option<TypeAnnotation> {
        let (name, span) = self.expect_ident()?;
        Some(TypeAnnotation { name, span })
    }

    /// `Const name = value` — valid both as a top-level item and as a
    /// statement inside a function body; both share this same parse (see
    /// [`kuro_ast::Stmt::ConstDecl`]) rather than duplicating it.
    pub(super) fn parse_const_decl(&mut self) -> Option<ConstDecl> {
        let start_span = self.expect(&TokenKind::Const, "'Const'")?;
        let (name, _) = self.expect_ident()?;
        self.expect(&TokenKind::Eq, "'='")?;
        let value = self.parse_expr()?;
        let span = start_span.to(value.span);
        Some(ConstDecl {
            name,
            type_annotation: None,
            value,
            span,
        })
    }
}
