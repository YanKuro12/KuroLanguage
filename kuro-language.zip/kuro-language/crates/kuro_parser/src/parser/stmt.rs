use super::Parser;
use kuro_ast::{
    AssignStmt, Block, ElseBranch, ExprStmt, ForStmt, ForeachStmt, IfStmt, ReturnStmt, Stmt,
    VarDecl, WhileStmt,
};
use kuro_lexer::TokenKind;

impl<'a> Parser<'a> {
    /// `{ statements... }`.
    pub(super) fn parse_block(&mut self) -> Option<Block> {
        let start_span = self.expect(&TokenKind::LBrace, "'{'")?;
        self.skip_newlines();
        let mut statements = Vec::new();
        while !self.is_at(&TokenKind::RBrace) && !self.is_at(&TokenKind::Eof) {
            match self.parse_stmt() {
                Some(stmt) => statements.push(stmt),
                None => self.synchronize_to_stmt_start(),
            }
            self.skip_newlines();
        }
        let end_span = self.expect(&TokenKind::RBrace, "'}'")?;
        let span = start_span.to(end_span);
        Some(Block { statements, span })
    }

    fn parse_stmt(&mut self) -> Option<Stmt> {
        if self.is_at(&TokenKind::Var) {
            return self.parse_var_decl().map(Stmt::VarDecl);
        }
        if self.is_at(&TokenKind::Const) {
            return self.parse_const_decl().map(Stmt::ConstDecl);
        }
        if self.is_at(&TokenKind::If) {
            return self.parse_if_stmt().map(Stmt::If);
        }
        if self.is_at(&TokenKind::While) {
            return self.parse_while_stmt().map(Stmt::While);
        }
        if self.is_at(&TokenKind::For) {
            return self.parse_for_stmt().map(Stmt::For);
        }
        if self.is_at(&TokenKind::Foreach) {
            return self.parse_foreach_stmt().map(Stmt::Foreach);
        }
        if self.is_at(&TokenKind::Return) {
            return self.parse_return_stmt().map(Stmt::Return);
        }
        if self.is_at(&TokenKind::Break) {
            let span = self.advance().span;
            return Some(Stmt::Break(span));
        }
        if self.is_at(&TokenKind::Continue) {
            let span = self.advance().span;
            return Some(Stmt::Continue(span));
        }
        if self.is_at(&TokenKind::LBrace) {
            return self.parse_block().map(Stmt::Block);
        }
        self.parse_expr_or_assign_stmt()
    }

    /// `Var name = value`. No explicit type annotation form is confirmed
    /// yet (every example infers the type from `value`), so
    /// `type_annotation` is always `None` for now — the field already
    /// exists on [`VarDecl`] for when that's confirmed.
    fn parse_var_decl(&mut self) -> Option<VarDecl> {
        let start_span = self.expect(&TokenKind::Var, "'Var'")?;
        let (name, _) = self.expect_ident()?;
        self.expect(&TokenKind::Eq, "'='")?;
        let value = self.parse_expr()?;
        let span = start_span.to(value.span);
        Some(VarDecl {
            name,
            type_annotation: None,
            value,
            span,
        })
    }

    /// A bare expression statement (e.g. `Console.Print("hi")`) or an
    /// assignment (`x = 5`) — both start with an expression, so they
    /// share one parse until an `=` shows up (or doesn't).
    fn parse_expr_or_assign_stmt(&mut self) -> Option<Stmt> {
        let expr = self.parse_expr()?;
        if self.is_at(&TokenKind::Eq) {
            self.advance();
            let value = self.parse_expr()?;
            let span = expr.span.to(value.span);
            return Some(Stmt::Assign(AssignStmt {
                target: expr,
                value,
                span,
            }));
        }
        let span = expr.span;
        Some(Stmt::Expr(ExprStmt { expr, span }))
    }

    /// `If condition { ... }`, optionally followed by `Else If ...` or
    /// `Else { ... }`.
    fn parse_if_stmt(&mut self) -> Option<IfStmt> {
        let start_span = self.expect(&TokenKind::If, "'If'")?;
        let condition = self.parse_expr()?;
        let then_branch = self.parse_block()?;
        let else_branch = self.parse_optional_else_branch()?;
        let end_span = match &else_branch {
            Some(ElseBranch::ElseIf(nested)) => nested.span,
            Some(ElseBranch::Else(block)) => block.span,
            None => then_branch.span,
        };
        let span = start_span.to(end_span);
        Some(IfStmt {
            condition,
            then_branch,
            else_branch,
            span,
        })
    }

    fn parse_optional_else_branch(&mut self) -> Option<Option<ElseBranch>> {
        if !self.is_at(&TokenKind::Else) {
            return Some(None);
        }
        self.advance();
        if self.is_at(&TokenKind::If) {
            let nested = self.parse_if_stmt()?;
            return Some(Some(ElseBranch::ElseIf(Box::new(nested))));
        }
        let block = self.parse_block()?;
        Some(Some(ElseBranch::Else(block)))
    }

    /// `While condition { ... }`.
    fn parse_while_stmt(&mut self) -> Option<WhileStmt> {
        let start_span = self.expect(&TokenKind::While, "'While'")?;
        let condition = self.parse_expr()?;
        let body = self.parse_block()?;
        let span = start_span.to(body.span);
        Some(WhileStmt {
            condition,
            body,
            span,
        })
    }

    /// `For binding = start To end { ... }`, e.g. `For i = 0 To 10 { }`.
    fn parse_for_stmt(&mut self) -> Option<ForStmt> {
        let start_span = self.expect(&TokenKind::For, "'For'")?;
        let (binding, _) = self.expect_ident()?;
        self.expect(&TokenKind::Eq, "'='")?;
        let start = self.parse_expr()?;
        self.expect(&TokenKind::To, "'To'")?;
        let end = self.parse_expr()?;
        let body = self.parse_block()?;
        let span = start_span.to(body.span);
        Some(ForStmt {
            binding,
            start,
            end,
            body,
            span,
        })
    }

    /// `Foreach binding In iterable { ... }`.
    fn parse_foreach_stmt(&mut self) -> Option<ForeachStmt> {
        let start_span = self.expect(&TokenKind::Foreach, "'Foreach'")?;
        let (binding, _) = self.expect_ident()?;
        self.expect(&TokenKind::In, "'In'")?;
        let iterable = self.parse_expr()?;
        let body = self.parse_block()?;
        let span = start_span.to(body.span);
        Some(ForeachStmt {
            binding,
            iterable,
            body,
            span,
        })
    }

    /// `Return` (no value) or `Return value`.
    fn parse_return_stmt(&mut self) -> Option<ReturnStmt> {
        let start_span = self.expect(&TokenKind::Return, "'Return'")?;
        if self.at_stmt_end() {
            return Some(ReturnStmt {
                value: None,
                span: start_span,
            });
        }
        let value = self.parse_expr()?;
        let span = start_span.to(value.span);
        Some(ReturnStmt {
            value: Some(value),
            span,
        })
    }
}
