use super::Parser;
use kuro_ast::{BinaryOp, Expr, ExprKind, UnaryOp};
use kuro_lexer::TokenKind;
use kuro_source::Span;

/// Expression grammar, lowest to highest precedence:
/// `Or -> And -> Equality -> Comparison -> Additive -> Multiplicative ->
/// Unary -> Postfix (call, member) -> Primary`.
impl<'a> Parser<'a> {
    pub(super) fn parse_expr(&mut self) -> Option<Expr> {
        self.parse_or()
    }

    fn parse_or(&mut self) -> Option<Expr> {
        let mut left = self.parse_and()?;
        while self.is_at(&TokenKind::OrOr) {
            self.advance();
            let right = self.parse_and()?;
            let span = left.span.to(right.span);
            left = Expr::new(
                ExprKind::Binary(Box::new(left), BinaryOp::Or, Box::new(right)),
                span,
            );
        }
        Some(left)
    }

    fn parse_and(&mut self) -> Option<Expr> {
        let mut left = self.parse_equality()?;
        while self.is_at(&TokenKind::AndAnd) {
            self.advance();
            let right = self.parse_equality()?;
            let span = left.span.to(right.span);
            left = Expr::new(
                ExprKind::Binary(Box::new(left), BinaryOp::And, Box::new(right)),
                span,
            );
        }
        Some(left)
    }

    fn parse_equality(&mut self) -> Option<Expr> {
        let mut left = self.parse_comparison()?;
        while let Some(op) = self.peek_equality_op() {
            self.advance();
            let right = self.parse_comparison()?;
            let span = left.span.to(right.span);
            left = Expr::new(ExprKind::Binary(Box::new(left), op, Box::new(right)), span);
        }
        Some(left)
    }

    fn peek_equality_op(&self) -> Option<BinaryOp> {
        match self.peek_kind() {
            TokenKind::EqEq => Some(BinaryOp::Eq),
            TokenKind::NotEq => Some(BinaryOp::NotEq),
            _ => None,
        }
    }

    fn parse_comparison(&mut self) -> Option<Expr> {
        let mut left = self.parse_additive()?;
        while let Some(op) = self.peek_comparison_op() {
            self.advance();
            let right = self.parse_additive()?;
            let span = left.span.to(right.span);
            left = Expr::new(ExprKind::Binary(Box::new(left), op, Box::new(right)), span);
        }
        Some(left)
    }

    fn peek_comparison_op(&self) -> Option<BinaryOp> {
        match self.peek_kind() {
            TokenKind::Lt => Some(BinaryOp::Lt),
            TokenKind::Gt => Some(BinaryOp::Gt),
            TokenKind::LtEq => Some(BinaryOp::LtEq),
            TokenKind::GtEq => Some(BinaryOp::GtEq),
            _ => None,
        }
    }

    fn parse_additive(&mut self) -> Option<Expr> {
        let mut left = self.parse_multiplicative()?;
        while let Some(op) = self.peek_additive_op() {
            self.advance();
            let right = self.parse_multiplicative()?;
            let span = left.span.to(right.span);
            left = Expr::new(ExprKind::Binary(Box::new(left), op, Box::new(right)), span);
        }
        Some(left)
    }

    fn peek_additive_op(&self) -> Option<BinaryOp> {
        match self.peek_kind() {
            TokenKind::Plus => Some(BinaryOp::Add),
            TokenKind::Minus => Some(BinaryOp::Sub),
            _ => None,
        }
    }

    fn parse_multiplicative(&mut self) -> Option<Expr> {
        let mut left = self.parse_unary()?;
        while let Some(op) = self.peek_multiplicative_op() {
            self.advance();
            let right = self.parse_unary()?;
            let span = left.span.to(right.span);
            left = Expr::new(ExprKind::Binary(Box::new(left), op, Box::new(right)), span);
        }
        Some(left)
    }

    fn peek_multiplicative_op(&self) -> Option<BinaryOp> {
        match self.peek_kind() {
            TokenKind::Star => Some(BinaryOp::Mul),
            TokenKind::Slash => Some(BinaryOp::Div),
            TokenKind::Percent => Some(BinaryOp::Mod),
            _ => None,
        }
    }

    /// Right-recursive so chained unary operators (e.g. `!!x`) parse, even
    /// though nothing in the confirmed spec exercises that yet.
    fn parse_unary(&mut self) -> Option<Expr> {
        if let Some(op) = self.peek_unary_op() {
            let start_span = self.peek().span;
            self.advance();
            let operand = self.parse_unary()?;
            let span = start_span.to(operand.span);
            return Some(Expr::new(ExprKind::Unary(op, Box::new(operand)), span));
        }
        self.parse_postfix()
    }

    fn peek_unary_op(&self) -> Option<UnaryOp> {
        match self.peek_kind() {
            TokenKind::Minus => Some(UnaryOp::Neg),
            TokenKind::Not => Some(UnaryOp::Not),
            _ => None,
        }
    }

    /// Handles `.name` (member access) and `(args)` (call) chains after a
    /// primary expression, e.g. `Console.Print("hi")` is
    /// primary(`Console`) → member(`.Print`) → call(`("hi")`).
    fn parse_postfix(&mut self) -> Option<Expr> {
        let mut expr = self.parse_primary()?;
        loop {
            if self.is_at(&TokenKind::Dot) {
                self.advance();
                let (name, name_span) = self.expect_ident()?;
                let span = expr.span.to(name_span);
                expr = Expr::new(ExprKind::Member(Box::new(expr), name), span);
            } else if self.is_at(&TokenKind::LParen) {
                self.advance();
                let args = self.parse_call_args()?;
                let close_span = self.expect(&TokenKind::RParen, "')'")?;
                let span = expr.span.to(close_span);
                expr = Expr::new(ExprKind::Call(Box::new(expr), args), span);
            } else {
                break;
            }
        }
        Some(expr)
    }

    fn parse_call_args(&mut self) -> Option<Vec<Expr>> {
        let mut args = Vec::new();
        if self.is_at(&TokenKind::RParen) {
            return Some(args);
        }
        loop {
            args.push(self.parse_expr()?);
            if self.is_at(&TokenKind::Comma) {
                self.advance();
            } else {
                break;
            }
        }
        Some(args)
    }

    fn parse_primary(&mut self) -> Option<Expr> {
        if let Some((value, span)) = self.take_int() {
            return Some(Expr::new(ExprKind::IntLiteral(value), span));
        }
        if let Some((value, span)) = self.take_float() {
            return Some(Expr::new(ExprKind::FloatLiteral(value), span));
        }
        if let Some((value, span)) = self.take_str() {
            return Some(Expr::new(ExprKind::StringLiteral(value), span));
        }
        if self.is_at(&TokenKind::True) {
            let span = self.advance().span;
            return Some(Expr::new(ExprKind::BoolLiteral(true), span));
        }
        if self.is_at(&TokenKind::False) {
            let span = self.advance().span;
            return Some(Expr::new(ExprKind::BoolLiteral(false), span));
        }
        if self.is_at(&TokenKind::Null) {
            let span = self.advance().span;
            return Some(Expr::new(ExprKind::NullLiteral, span));
        }
        if let Some((name, span)) = self.take_ident() {
            return Some(Expr::new(ExprKind::Ident(name), span));
        }
        if self.is_at(&TokenKind::LParen) {
            self.advance();
            let inner = self.parse_expr()?;
            self.expect(&TokenKind::RParen, "')'")?;
            return Some(inner);
        }
        let span = self.peek().span;
        self.error_with_suggestion(
            "Expected an expression",
            span,
            "Check for a missing value or a typo.",
        );
        None
    }

    fn take_int(&mut self) -> Option<(i64, Span)> {
        let value = match self.peek_kind() {
            TokenKind::Int(v) => Some(*v),
            _ => None,
        }?;
        let span = self.advance().span;
        Some((value, span))
    }

    fn take_float(&mut self) -> Option<(f64, Span)> {
        let value = match self.peek_kind() {
            TokenKind::Float(v) => Some(*v),
            _ => None,
        }?;
        let span = self.advance().span;
        Some((value, span))
    }

    fn take_str(&mut self) -> Option<(String, Span)> {
        let value = match self.peek_kind() {
            TokenKind::Str(v) => Some(v.clone()),
            _ => None,
        }?;
        let span = self.advance().span;
        Some((value, span))
    }
}
