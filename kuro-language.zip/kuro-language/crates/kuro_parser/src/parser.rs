use kuro_ast::Program;
use kuro_diagnostics::{Diagnostic, Diagnostics};
use kuro_lexer::{Token, TokenKind};
use kuro_source::Span;

mod expr;
mod item;
mod stmt;

/// Turns a token stream into a [`Program`].
///
/// Construct with [`Parser::new`], then call [`Parser::parse_program`].
/// Like the lexer, parsing never stops at the first problem: a malformed
/// statement or item is reported as a [`Diagnostic`] and the parser skips
/// ahead to the next statement or item boundary and keeps going, so one
/// run can surface more than one syntax error at once.
///
/// Trivia tokens (`LineComment`, `BlockComment`) are skipped automatically
/// — they matter to `kuro_formatter`, which is expected to work from the
/// raw token stream directly rather than from this parser's output.
pub struct Parser<'a> {
    tokens: &'a [Token],
    pos: usize,
    diagnostics: Diagnostics,
}

impl<'a> Parser<'a> {
    pub fn new(tokens: &'a [Token]) -> Self {
        let mut parser = Parser {
            tokens,
            pos: 0,
            diagnostics: Diagnostics::new(),
        };
        parser.skip_trivia();
        parser
    }

    pub fn parse_program(mut self) -> (Program, Diagnostics) {
        let start_span = self.peek().span;
        let mut items = Vec::new();
        while !self.is_at(&TokenKind::Eof) {
            match self.parse_item() {
                Some(item) => items.push(item),
                None => self.synchronize_to_item_start(),
            }
        }
        let end_span = self.peek().span;
        let span = start_span.to(end_span);
        (Program { items, span }, self.diagnostics)
    }

    // --- cursor helpers --------------------------------------------

    fn skip_trivia(&mut self) {
        while matches!(
            self.peek_kind(),
            TokenKind::LineComment(_) | TokenKind::BlockComment(_)
        ) {
            self.pos += 1;
        }
    }

    fn peek(&self) -> &'a Token {
        &self.tokens[self.pos]
    }

    fn peek_kind(&self) -> &'a TokenKind {
        &self.tokens[self.pos].kind
    }

    fn is_at(&self, kind: &TokenKind) -> bool {
        self.peek_kind() == kind
    }

    /// Consumes and returns the current token, skipping any trivia that
    /// follows it. Never advances past `Eof`, so calling this repeatedly
    /// once at end-of-file is always safe.
    fn advance(&mut self) -> &'a Token {
        let idx = self.pos;
        if !self.is_at(&TokenKind::Eof) {
            self.pos += 1;
            self.skip_trivia();
        }
        &self.tokens[idx]
    }

    /// Skips any number of `Newline` tokens.
    fn skip_newlines(&mut self) {
        while self.is_at(&TokenKind::Newline) {
            self.advance();
        }
    }

    /// True at a `Newline`, the `}` closing the enclosing block, or `Eof`
    /// — the points where a statement is allowed to end.
    fn at_stmt_end(&self) -> bool {
        self.is_at(&TokenKind::Newline) || self.is_at(&TokenKind::RBrace) || self.is_at(&TokenKind::Eof)
    }

    /// If the current token is exactly `kind`, consumes it and returns its
    /// span; otherwise records a diagnostic naming `what` and returns
    /// `None`, leaving the cursor unchanged.
    fn expect(&mut self, kind: &TokenKind, what: &str) -> Option<Span> {
        if self.is_at(kind) {
            return Some(self.advance().span);
        }
        let span = self.peek().span;
        self.error(format!("Expected {what}"), span);
        None
    }

    /// If the current token is an identifier, consumes it and returns its
    /// name and span; otherwise leaves the cursor unchanged and returns
    /// `None` without recording an error — used where the caller has
    /// other alternatives to try (e.g. when parsing a primary expression,
    /// where an identifier is only one of several possibilities).
    fn take_ident(&mut self) -> Option<(String, Span)> {
        let name = match self.peek_kind() {
            TokenKind::Ident(v) => Some(v.clone()),
            _ => None,
        }?;
        let span = self.advance().span;
        Some((name, span))
    }

    /// Like [`Self::take_ident`], but records a diagnostic if the current
    /// token isn't an identifier — used where an identifier is the only
    /// thing that could come next.
    fn expect_ident(&mut self) -> Option<(String, Span)> {
        if let Some(result) = self.take_ident() {
            return Some(result);
        }
        let span = self.peek().span;
        self.error("Expected an identifier", span);
        None
    }

    fn error(&mut self, message: impl Into<String>, span: Span) {
        self.diagnostics.push(Diagnostic::error(message, span));
    }

    fn error_with_suggestion(
        &mut self,
        message: impl Into<String>,
        span: Span,
        suggestion: impl Into<String>,
    ) {
        self.diagnostics
            .push(Diagnostic::error(message, span).with_suggestion(suggestion));
    }

    // --- error recovery --------------------------------------------

    /// Recovery for a failed top-level item: skips tokens until the next
    /// plausible item start (`Func`/`Const`) or `Eof`.
    fn synchronize_to_item_start(&mut self) {
        while !self.is_at(&TokenKind::Eof)
            && !self.is_at(&TokenKind::Func)
            && !self.is_at(&TokenKind::Const)
        {
            self.advance();
        }
    }

    /// Recovery for a failed statement: skips tokens until the next
    /// `Newline`, a `}` that closes the enclosing block, or `Eof`,
    /// consuming a trailing `Newline` if that's what stopped it.
    fn synchronize_to_stmt_start(&mut self) {
        while !self.at_stmt_end() {
            self.advance();
        }
        if self.is_at(&TokenKind::Newline) {
            self.advance();
        }
    }
}
