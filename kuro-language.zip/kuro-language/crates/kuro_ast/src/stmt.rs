use crate::expr::Expr;
use crate::item::{ConstDecl, TypeAnnotation};
use kuro_source::Span;

/// A brace-delimited sequence of statements, e.g. a function or loop body.
#[derive(Debug, Clone, PartialEq)]
pub struct Block {
    pub statements: Vec<Stmt>,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq)]
pub enum Stmt {
    VarDecl(VarDecl),
    ConstDecl(ConstDecl),
    Assign(AssignStmt),
    Expr(ExprStmt),
    If(IfStmt),
    While(WhileStmt),
    For(ForStmt),
    Foreach(ForeachStmt),
    Return(ReturnStmt),
    Break(Span),
    Continue(Span),
    Block(Block),
}

impl Stmt {
    /// The span of source text this statement came from.
    pub fn span(&self) -> Span {
        match self {
            Stmt::VarDecl(s) => s.span,
            Stmt::ConstDecl(s) => s.span,
            Stmt::Assign(s) => s.span,
            Stmt::Expr(s) => s.span,
            Stmt::If(s) => s.span,
            Stmt::While(s) => s.span,
            Stmt::For(s) => s.span,
            Stmt::Foreach(s) => s.span,
            Stmt::Return(s) => s.span,
            Stmt::Break(span) | Stmt::Continue(span) => *span,
            Stmt::Block(b) => b.span,
        }
    }
}

/// `Var name = value`, optionally with an explicit type:
/// `Var name Type = value`.
#[derive(Debug, Clone, PartialEq)]
pub struct VarDecl {
    pub name: String,
    pub type_annotation: Option<TypeAnnotation>,
    pub value: Expr,
    pub span: Span,
}

/// `target = value` — reassigning an existing binding. A new binding uses
/// [`VarDecl`] instead. `target` is a full expression (not just a name) so
/// this can later cover things like member or index assignment once those
/// exist; the parser/semantic stage is responsible for rejecting targets
/// that aren't actually assignable.
#[derive(Debug, Clone, PartialEq)]
pub struct AssignStmt {
    pub target: Expr,
    pub value: Expr,
    pub span: Span,
}

/// An expression used on its own as a statement, e.g. a bare
/// `Console.Print("hi")` call.
#[derive(Debug, Clone, PartialEq)]
pub struct ExprStmt {
    pub expr: Expr,
    pub span: Span,
}

/// `If condition { ... }`, optionally followed by `Else If`/`Else`.
#[derive(Debug, Clone, PartialEq)]
pub struct IfStmt {
    pub condition: Expr,
    pub then_branch: Block,
    pub else_branch: Option<ElseBranch>,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq)]
pub enum ElseBranch {
    /// `Else If ...` — chains into another `IfStmt`.
    ElseIf(Box<IfStmt>),
    /// A plain `Else { ... }`.
    Else(Block),
}

/// `While condition { ... }`.
#[derive(Debug, Clone, PartialEq)]
pub struct WhileStmt {
    pub condition: Expr,
    pub body: Block,
    pub span: Span,
}

/// `For binding = start To end { ... }`, e.g. `For i = 0 To 10 { }`.
#[derive(Debug, Clone, PartialEq)]
pub struct ForStmt {
    pub binding: String,
    pub start: Expr,
    pub end: Expr,
    pub body: Block,
    pub span: Span,
}

/// `Foreach binding in iterable { ... }` — iterates over a collection.
#[derive(Debug, Clone, PartialEq)]
pub struct ForeachStmt {
    pub binding: String,
    pub iterable: Expr,
    pub body: Block,
    pub span: Span,
}

/// `Return` or `Return value`.
#[derive(Debug, Clone, PartialEq)]
pub struct ReturnStmt {
    pub value: Option<Expr>,
    pub span: Span,
}
