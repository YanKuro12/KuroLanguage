use kuro_source::Span;

/// An expression: something that evaluates to a value.
#[derive(Debug, Clone, PartialEq)]
pub struct Expr {
    pub kind: ExprKind,
    pub span: Span,
}

impl Expr {
    pub fn new(kind: ExprKind, span: Span) -> Self {
        Expr { kind, span }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum ExprKind {
    IntLiteral(i64),
    FloatLiteral(f64),
    StringLiteral(String),
    BoolLiteral(bool),
    NullLiteral,

    /// A bare name, e.g. `x` or `Console`. Could refer to a variable, a
    /// function, or a standard library module — which one is decided
    /// during semantic analysis, not here.
    Ident(String),

    Binary(Box<Expr>, BinaryOp, Box<Expr>),
    Unary(UnaryOp, Box<Expr>),

    /// A call: `callee(args)`, e.g. `Main()` or `Console.Print("hi")`
    /// (where the callee is itself a `Member` expression).
    Call(Box<Expr>, Vec<Expr>),

    /// Namespace/member access: `object.name`, e.g. `Console.Print`.
    Member(Box<Expr>, String),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinaryOp {
    Add,
    Sub,
    Mul,
    Div,
    Mod,
    Eq,
    NotEq,
    Lt,
    Gt,
    LtEq,
    GtEq,
    And,
    Or,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnaryOp {
    /// Numeric negation: `-x`.
    Neg,
    /// Logical negation: `!x`.
    Not,
}
