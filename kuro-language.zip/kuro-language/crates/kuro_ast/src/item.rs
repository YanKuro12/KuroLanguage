use crate::expr::Expr;
use crate::stmt::Block;
use kuro_source::Span;

/// A whole source file: a sequence of top-level items.
#[derive(Debug, Clone, PartialEq)]
pub struct Program {
    pub items: Vec<Item>,
    pub span: Span,
}

/// Something that can appear at the top level of a `.kr` file.
#[derive(Debug, Clone, PartialEq)]
pub enum Item {
    Function(FunctionDecl),
    Const(ConstDecl),
}

/// `Func name(params) ReturnType { body }`.
#[derive(Debug, Clone, PartialEq)]
pub struct FunctionDecl {
    pub name: String,
    pub params: Vec<Param>,
    pub return_type: Option<TypeAnnotation>,
    pub body: Block,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Param {
    pub name: String,
    pub type_annotation: TypeAnnotation,
    pub span: Span,
}

/// `Const name = value`, valid both at the top level and inside a function
/// body (see [`crate::stmt::Stmt::ConstDecl`]) — the two share this same
/// type rather than duplicating it.
#[derive(Debug, Clone, PartialEq)]
pub struct ConstDecl {
    pub name: String,
    pub type_annotation: Option<TypeAnnotation>,
    pub value: Expr,
    pub span: Span,
}

/// A type as written in source, e.g. `Int` or `String`. Kept as a plain
/// name for now — resolving it to an actual built-in or user-defined type
/// is `kuro_semantic`'s job, not this crate's.
#[derive(Debug, Clone, PartialEq)]
pub struct TypeAnnotation {
    pub name: String,
    pub span: Span,
}
