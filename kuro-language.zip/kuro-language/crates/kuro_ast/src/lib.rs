//! Abstract syntax tree types for KuroLanguage.
//!
//! This crate depends only on [`kuro_source`] for position tracking. It
//! does not depend on `kuro_lexer`: nothing here needs to know how source
//! text became tokens, only the shape of a parsed program — so `kuro_lexer`
//! can keep changing internally without ever requiring a change here, and
//! `kuro_parser` (which will depend on both) is the only place that
//! connects the two, matching the pipeline direction (Lexer → AST →
//! Parser).

mod expr;
mod item;
mod stmt;

pub use expr::{BinaryOp, Expr, ExprKind, UnaryOp};
pub use item::{ConstDecl, FunctionDecl, Item, Param, Program, TypeAnnotation};
pub use stmt::{
    AssignStmt, Block, ElseBranch, ExprStmt, ForStmt, ForeachStmt, IfStmt, ReturnStmt, Stmt,
    VarDecl, WhileStmt,
};

#[cfg(test)]
mod tests {
    use super::*;
    use kuro_source::{SourceMap, Span};

    fn dummy_span(sources: &mut SourceMap) -> Span {
        let id = sources.add_file("test.kr", "");
        Span::new(id, 0, 0)
    }

    #[test]
    fn stmt_span_matches_inner_span() {
        let mut sources = SourceMap::new();
        let span = dummy_span(&mut sources);

        let brk = Stmt::Break(span);
        assert_eq!(brk.span(), span);

        let ret = Stmt::Return(ReturnStmt {
            value: None,
            span,
        });
        assert_eq!(ret.span(), span);
    }

    #[test]
    fn builds_a_small_function() {
        // Represents:
        // Func Main() {
        //     Var x = 1
        // }
        let mut sources = SourceMap::new();
        let span = dummy_span(&mut sources);

        let var_decl = Stmt::VarDecl(VarDecl {
            name: "x".to_string(),
            type_annotation: None,
            value: Expr::new(ExprKind::IntLiteral(1), span),
            span,
        });

        let function = FunctionDecl {
            name: "Main".to_string(),
            params: Vec::new(),
            return_type: None,
            body: Block {
                statements: vec![var_decl],
                span,
            },
            span,
        };

        let program = Program {
            items: vec![Item::Function(function)],
            span,
        };

        assert_eq!(program.items.len(), 1);
        match &program.items[0] {
            Item::Function(f) => {
                assert_eq!(f.name, "Main");
                assert_eq!(f.body.statements.len(), 1);
            }
            Item::Const(_) => panic!("expected a function item, got a const item"),
        }
    }

    #[test]
    fn for_loop_matches_counting_form() {
        // Represents: For i = 0 To 10 { }
        let mut sources = SourceMap::new();
        let span = dummy_span(&mut sources);
        let for_stmt = ForStmt {
            binding: "i".to_string(),
            start: Expr::new(ExprKind::IntLiteral(0), span),
            end: Expr::new(ExprKind::IntLiteral(10), span),
            body: Block {
                statements: Vec::new(),
                span,
            },
            span,
        };
        assert_eq!(for_stmt.binding, "i");
        assert_eq!(for_stmt.start.kind, ExprKind::IntLiteral(0));
        assert_eq!(for_stmt.end.kind, ExprKind::IntLiteral(10));
    }

    #[test]
    fn member_call_shape_matches_console_print() {
        // Represents: Console.Print("hi")
        let mut sources = SourceMap::new();
        let span = dummy_span(&mut sources);

        let console = Expr::new(ExprKind::Ident("Console".to_string()), span);
        let member = Expr::new(
            ExprKind::Member(Box::new(console), "Print".to_string()),
            span,
        );
        let call = Expr::new(
            ExprKind::Call(
                Box::new(member),
                vec![Expr::new(ExprKind::StringLiteral("hi".to_string()), span)],
            ),
            span,
        );

        // Confirms the nested Call(Member(...)) shape actually constructs
        // and holds the right data, without relying on destructuring it
        // back apart (kuro_parser's tests are the right place for that
        // once it exists).
        let rendered = format!("{call:?}");
        assert!(rendered.contains("Console"));
        assert!(rendered.contains("Print"));
        assert!(rendered.contains("hi"));
    }
}
