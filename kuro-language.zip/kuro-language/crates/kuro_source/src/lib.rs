//! Source text and position tracking shared across the KuroLanguage toolchain.
//!
//! This crate has no dependency on any other `kuro_*` crate. It owns source
//! file content and provides byte-offset spans plus line/column resolution,
//! so that `kuro_lexer`, `kuro_parser`, `kuro_semantic`, and later stages can
//! all report positions the same way instead of duplicating this logic or
//! drifting into inconsistent conventions.

use std::fmt;

/// Opaque identifier for a source file loaded into a [`SourceMap`].
///
/// A [`Span`] carries a `SourceId` so it stays meaningful once a compilation
/// involves more than one file (e.g. once module imports exist) instead of
/// only being valid relative to some implicit "current file".
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct SourceId(u32);

/// A byte-offset range into one specific source file.
///
/// `start` is inclusive and `end` is exclusive, like a Rust slice range.
/// Offsets are stored as `u32` rather than `usize`: a `Span` is embedded in
/// every token and AST node, so keeping it at 12 bytes instead of 24
/// (on 64-bit) matters once there are millions of them. Both offsets must
/// land on UTF-8 character boundaries; every span `kuro_lexer` produces from
/// its own scanning satisfies this automatically.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Span {
    pub source: SourceId,
    pub start: u32,
    pub end: u32,
}

impl Span {
    pub fn new(source: SourceId, start: u32, end: u32) -> Self {
        debug_assert!(start <= end, "span start must not be after its end");
        Span { source, start, end }
    }

    /// Number of bytes covered by this span.
    pub fn len(&self) -> u32 {
        self.end - self.start
    }

    pub fn is_empty(&self) -> bool {
        self.start == self.end
    }

    /// The smallest span that fully contains both `self` and `other`.
    ///
    /// Panics if the two spans belong to different source files, since a
    /// single span cannot meaningfully cover two files at once.
    pub fn to(&self, other: Span) -> Span {
        assert_eq!(
            self.source, other.source,
            "cannot merge spans from two different source files"
        );
        Span {
            source: self.source,
            start: self.start.min(other.start),
            end: self.end.max(other.end),
        }
    }
}

/// A resolved 1-based line and column, ready to show to a person.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct LineColumn {
    pub line: u32,
    pub column: u32,
}

impl fmt::Display for LineColumn {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}:{}", self.line, self.column)
    }
}

/// One loaded source file: its display name, its full content, and a
/// precomputed index of line-start offsets so byte-offset-to-line/column
/// lookups don't have to rescan the file from the beginning every time.
#[derive(Debug)]
pub struct SourceFile {
    id: SourceId,
    name: String,
    content: String,
    /// Byte offset of the first character of each line. Always starts with
    /// `0`, since line 1 begins at the start of the file.
    line_starts: Vec<u32>,
}

impl SourceFile {
    fn new(id: SourceId, name: String, content: String) -> Self {
        let mut line_starts = vec![0u32];
        for (offset, ch) in content.char_indices() {
            if ch == '\n' {
                line_starts.push(offset as u32 + 1);
            }
        }
        SourceFile { id, name, content, line_starts }
    }

    pub fn id(&self) -> SourceId {
        self.id
    }

    pub fn name(&self) -> &str {
        &self.name
    }

    pub fn content(&self) -> &str {
        &self.content
    }

    /// The source text covered by `span`.
    ///
    /// Panics if `span` belongs to a different file or falls outside this
    /// file's content — both indicate a bug in the caller, not a normal
    /// runtime condition.
    pub fn text(&self, span: Span) -> &str {
        assert_eq!(span.source, self.id, "span belongs to a different file");
        &self.content[span.start as usize..span.end as usize]
    }

    /// Resolves a byte offset in this file to a 1-based line and column.
    ///
    /// The column counts `char`s, not bytes, so a multi-byte UTF-8 character
    /// still counts as one column — matching what a person actually sees.
    ///
    /// Panics if `offset` is past the end of this file's content.
    pub fn line_col(&self, offset: u32) -> LineColumn {
        assert!(
            offset as usize <= self.content.len(),
            "offset out of bounds for this source file"
        );
        let line_index = match self.line_starts.binary_search(&offset) {
            Ok(exact) => exact,
            Err(insert_at) => insert_at - 1,
        };
        let line_start = self.line_starts[line_index];
        let column = self.content[line_start as usize..offset as usize]
            .chars()
            .count() as u32
            + 1;
        LineColumn { line: line_index as u32 + 1, column }
    }
}

/// Owns every source file involved in a compilation and hands out
/// [`SourceId`]s for them.
///
/// This is the single source of truth later crates use to turn a [`Span`]
/// back into a file name, a line/column, or the underlying text, so that
/// behavior is identical everywhere it's needed instead of being
/// reimplemented per crate.
#[derive(Debug, Default)]
pub struct SourceMap {
    files: Vec<SourceFile>,
}

impl SourceMap {
    pub fn new() -> Self {
        SourceMap { files: Vec::new() }
    }

    /// Registers a new source file and returns its [`SourceId`].
    pub fn add_file(&mut self, name: impl Into<String>, content: impl Into<String>) -> SourceId {
        let id = SourceId(self.files.len() as u32);
        self.files.push(SourceFile::new(id, name.into(), content.into()));
        id
    }

    pub fn get(&self, id: SourceId) -> &SourceFile {
        &self.files[id.0 as usize]
    }

    pub fn line_col(&self, span: Span) -> LineColumn {
        self.get(span.source).line_col(span.start)
    }

    pub fn text(&self, span: Span) -> &str {
        self.get(span.source).text(span)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn single_line_positions() {
        let mut map = SourceMap::new();
        let id = map.add_file("main.kr", "Var x = 1");
        let span = Span::new(id, 4, 5); // the "x"
        assert_eq!(map.text(span), "x");
        assert_eq!(map.line_col(span), LineColumn { line: 1, column: 5 });
    }

    #[test]
    fn multi_line_positions() {
        let mut map = SourceMap::new();
        let content = "Func Main() {\n    Console.Print(\n}";
        let id = map.add_file("main.kr", content);
        let offset = content.rfind('}').unwrap() as u32;
        let span = Span::new(id, offset, offset + 1);
        let lc = map.line_col(span);
        assert_eq!(lc.line, 3);
        assert_eq!(lc.column, 1);
    }

    #[test]
    fn column_counts_chars_not_bytes() {
        let mut map = SourceMap::new();
        // "é" is 2 bytes in UTF-8 but must still count as a single column.
        let content = "Var é = 1";
        let id = map.add_file("main.kr", content);
        let offset = content.find('=').unwrap() as u32;
        let span = Span::new(id, offset, offset + 1);
        let lc = map.line_col(span);
        assert_eq!(lc.column, 7);
    }

    #[test]
    fn span_to_merges_ranges() {
        let mut map = SourceMap::new();
        let id = map.add_file("main.kr", "abcdef");
        let a = Span::new(id, 0, 2);
        let b = Span::new(id, 4, 6);
        assert_eq!(a.to(b), Span::new(id, 0, 6));
    }
}
