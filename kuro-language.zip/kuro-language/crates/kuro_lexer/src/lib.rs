//! Turns KuroLanguage source text into a token stream.
//!
//! This crate depends on [`kuro_source`] for position tracking and
//! [`kuro_diagnostics`] for reporting problems. It does not depend on
//! `kuro_ast`, `kuro_parser`, or any stage after itself, so those crates can
//! change freely without ever requiring a change here — matching the
//! pipeline direction (Source → Lexer → Parser → ...).

mod lexer;
mod token;

pub use lexer::Lexer;
pub use token::{Token, TokenKind};
