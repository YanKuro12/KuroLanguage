use kuro_source::Span;

/// The syntactic category of a single token, without its position.
///
/// See [`crate::Lexer`] for how KuroLanguage source text becomes a stream
/// of these.
#[derive(Debug, Clone, PartialEq)]
pub enum TokenKind {
    // Keywords
    Func,
    Var,
    Const,
    If,
    Else,
    While,
    For,
    Foreach,
    Return,
    Break,
    Continue,

    /// `To`, as in `For i = 0 To 10 { }` — separates a `For` loop's start
    /// and end expressions.
    To,
    /// `In`, as in `Foreach item In collection { }` — separates a
    /// `Foreach` loop's binding and the collection it iterates.
    In,

    // Literal keywords — lexed straight to a value instead of `Ident`,
    // since they always mean the same literal wherever they appear.
    True,
    False,
    Null,

    // Literals with a value
    Int(i64),
    Float(f64),
    Str(String),

    /// Anything that isn't one of the keywords above — this includes
    /// standard library names like `Console` and `Convert`. Whether an
    /// identifier refers to a stdlib module or a user symbol is decided
    /// during semantic analysis / name resolution, not here.
    Ident(String),

    // Operators
    Plus,
    Minus,
    Star,
    Slash,
    Percent,
    EqEq,
    NotEq,
    Lt,
    Gt,
    LtEq,
    GtEq,
    AndAnd,
    OrOr,
    Not,
    Eq,

    // Punctuation
    LParen,
    RParen,
    LBrace,
    RBrace,
    LBracket,
    RBracket,
    Comma,
    Dot,

    // Trivia — kept in the stream (not discarded) so `kuro_formatter` can
    // reproduce a file byte-for-byte later. `kuro_parser` skips these when
    // it asks for the next significant token. The stored text includes the
    // comment markers themselves (`//`, `/*`, `*/`).
    LineComment(String),
    BlockComment(String),

    /// A statement terminator. Emitted once for one or more consecutive
    /// newlines at bracket depth zero; never emitted while inside an
    /// unclosed `(` or `[`, so a call or array literal can span multiple
    /// lines. `{` / `}` do not affect this — statements inside a block
    /// still terminate at newlines normally.
    Newline,

    /// End of file. Always the last token produced.
    Eof,
}

/// One token together with the span of source text it came from.
#[derive(Debug, Clone, PartialEq)]
pub struct Token {
    pub kind: TokenKind,
    pub span: Span,
}

impl Token {
    pub fn new(kind: TokenKind, span: Span) -> Self {
        Token { kind, span }
    }
}
