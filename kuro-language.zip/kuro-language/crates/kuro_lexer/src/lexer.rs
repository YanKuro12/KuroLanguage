use crate::token::{Token, TokenKind};
use kuro_diagnostics::{Diagnostic, Diagnostics};
use kuro_source::{SourceId, Span};

/// Turns KuroLanguage source text into a stream of [`Token`]s.
///
/// Construct with [`Lexer::new`], then call [`Lexer::tokenize`]. Scanning
/// never stops at the first problem: an invalid character, an unterminated
/// string, or an unterminated block comment are all reported as
/// [`Diagnostic`]s and the lexer recovers and keeps going, so a single run
/// can surface everything wrong with a file at once instead of one error
/// per compile.
pub struct Lexer<'a> {
    source: &'a str,
    source_id: SourceId,
    pos: u32,
    /// Depth of unclosed `(` / `[`. While greater than zero, a newline is
    /// insignificant whitespace instead of a statement terminator — this
    /// is what lets a function call or array literal span multiple lines.
    /// `{` / `}` deliberately do not participate: a block body's own
    /// statements must keep terminating at newlines as normal.
    bracket_depth: u32,
    tokens: Vec<Token>,
    diagnostics: Diagnostics,
}

impl<'a> Lexer<'a> {
    pub fn new(source_id: SourceId, source: &'a str) -> Self {
        Lexer {
            source,
            source_id,
            pos: 0,
            bracket_depth: 0,
            tokens: Vec::new(),
            diagnostics: Diagnostics::new(),
        }
    }

    /// Scans the whole source and returns every token together with any
    /// diagnostics collected along the way. The last token is always
    /// [`TokenKind::Eof`].
    pub fn tokenize(mut self) -> (Vec<Token>, Diagnostics) {
        while let Some(ch) = self.peek() {
            self.scan_one(ch);
        }
        let eof_span = self.span_at(self.pos, self.pos);
        self.push_token(TokenKind::Eof, eof_span);
        (self.tokens, self.diagnostics)
    }

    // --- low-level cursor helpers ------------------------------------

    fn peek(&self) -> Option<char> {
        self.source[self.pos as usize..].chars().next()
    }

    fn peek_second(&self) -> Option<char> {
        let mut chars = self.source[self.pos as usize..].chars();
        chars.next();
        chars.next()
    }

    fn advance(&mut self) -> Option<char> {
        let ch = self.peek()?;
        self.pos += ch.len_utf8() as u32;
        Some(ch)
    }

    fn span_at(&self, start: u32, end: u32) -> Span {
        Span::new(self.source_id, start, end)
    }

    /// Pushes a token. Takes an already-computed [`Span`] (rather than the
    /// `start`/`end` offsets) so every call site resolves the span into a
    /// local value first, before touching `self.tokens` — kept deliberately
    /// separate from the borrow of `self` needed to compute the span.
    fn push_token(&mut self, kind: TokenKind, span: Span) {
        self.tokens.push(Token::new(kind, span));
    }

    /// Same reasoning as [`Self::push_token`]: takes an already-built
    /// [`Diagnostic`] rather than assembling one from parts that would
    /// otherwise borrow `self` while `self.diagnostics` is being mutated.
    fn push_diagnostic(&mut self, diagnostic: Diagnostic) {
        self.diagnostics.push(diagnostic);
    }

    // --- top-level dispatch --------------------------------------------

    fn scan_one(&mut self, ch: char) {
        match ch {
            '\n' => self.scan_newline(),
            ' ' | '\t' | '\r' => {
                self.advance();
            }
            '/' if self.peek_second() == Some('/') => self.scan_line_comment(),
            '/' if self.peek_second() == Some('*') => self.scan_block_comment(),
            '"' => self.scan_string(),
            '0'..='9' => self.scan_number(),
            c if is_ident_start(c) => self.scan_ident_or_keyword(),
            _ => self.scan_operator_or_punct(ch),
        }
    }

    fn scan_newline(&mut self) {
        let start = self.pos;
        self.advance(); // the '\n' that triggered this call
        if self.bracket_depth > 0 {
            return;
        }
        // Coalesce further blank lines (and the indentation leading into
        // the next real token) into this one terminator, so e.g. two
        // blank lines in a row still produce a single `Newline`.
        loop {
            match self.peek() {
                Some(' ') | Some('\t') | Some('\r') | Some('\n') => {
                    self.advance();
                }
                _ => break,
            }
        }
        let span = self.span_at(start, self.pos);
        self.push_token(TokenKind::Newline, span);
    }

    fn scan_line_comment(&mut self) {
        let start = self.pos;
        self.advance(); // '/'
        self.advance(); // '/'
        while let Some(c) = self.peek() {
            if c == '\n' {
                break;
            }
            self.advance();
        }
        let text = self.source[start as usize..self.pos as usize].to_string();
        let span = self.span_at(start, self.pos);
        self.push_token(TokenKind::LineComment(text), span);
    }

    /// Block comments do not nest: the first `*/` found closes the comment,
    /// even if a `/*` appeared inside it.
    fn scan_block_comment(&mut self) {
        let start = self.pos;
        self.advance(); // '/'
        self.advance(); // '*'
        loop {
            match self.peek() {
                None => {
                    let span = self.span_at(start, self.pos);
                    let diagnostic = Diagnostic::error("Unterminated block comment", span)
                        .with_suggestion("Add '*/' to close this comment.");
                    self.push_diagnostic(diagnostic);
                    break;
                }
                Some('*') if self.peek_second() == Some('/') => {
                    self.advance();
                    self.advance();
                    break;
                }
                Some(_) => {
                    self.advance();
                }
            }
        }
        let text = self.source[start as usize..self.pos as usize].to_string();
        let span = self.span_at(start, self.pos);
        self.push_token(TokenKind::BlockComment(text), span);
    }

    /// String literals are single-line: a raw newline before the closing
    /// `"` ends the string with an "unterminated" error instead of being
    /// included in it. Use `\n` to put a newline in string content.
    fn scan_string(&mut self) {
        let start = self.pos;
        self.advance(); // opening '"'
        let mut value = String::new();
        loop {
            match self.peek() {
                None | Some('\n') => {
                    let span = self.span_at(start, self.pos);
                    let diagnostic = Diagnostic::error("Unterminated string literal", span)
                        .with_suggestion("Add a closing '\"'.");
                    self.push_diagnostic(diagnostic);
                    break;
                }
                Some('"') => {
                    self.advance();
                    break;
                }
                Some('\\') => {
                    self.advance();
                    self.scan_escape(&mut value);
                }
                Some(c) => {
                    value.push(c);
                    self.advance();
                }
            }
        }
        let span = self.span_at(start, self.pos);
        self.push_token(TokenKind::Str(value), span);
    }

    /// Handles the character(s) after a `\` inside a string. `self.pos` is
    /// positioned right after the backslash when this is called.
    fn scan_escape(&mut self, value: &mut String) {
        let backslash_start = self.pos - 1;
        match self.peek() {
            Some('n') => {
                value.push('\n');
                self.advance();
            }
            Some('t') => {
                value.push('\t');
                self.advance();
            }
            Some('r') => {
                value.push('\r');
                self.advance();
            }
            Some('\\') => {
                value.push('\\');
                self.advance();
            }
            Some('"') => {
                value.push('"');
                self.advance();
            }
            Some('0') => {
                value.push('\0');
                self.advance();
            }
            Some(other) => {
                self.advance();
                let span = self.span_at(backslash_start, self.pos);
                let diagnostic =
                    Diagnostic::error(format!("Unknown escape sequence '\\{other}'"), span)
                        .with_suggestion(
                            "Supported escapes are \\n, \\t, \\r, \\\\, \\\", and \\0.",
                        );
                self.push_diagnostic(diagnostic);
                // Recover by keeping the character as-is so the rest of
                // the string still scans normally.
                value.push(other);
            }
            None => {
                // Nothing left; the enclosing loop's EOF arm reports the
                // unterminated string.
            }
        }
    }

    fn scan_number(&mut self) {
        let start = self.pos;
        self.consume_digits();
        let mut is_float = false;
        if self.peek() == Some('.') && matches!(self.peek_second(), Some('0'..='9')) {
            is_float = true;
            self.advance(); // '.'
            self.consume_digits();
        }
        let text = self.source[start as usize..self.pos as usize].to_string();
        let span = self.span_at(start, self.pos);
        if is_float {
            match text.parse::<f64>() {
                Ok(value) => self.push_token(TokenKind::Float(value), span),
                Err(_) => {
                    let diagnostic =
                        Diagnostic::error(format!("Invalid float literal '{text}'"), span)
                            .with_suggestion("Numbers should look like 3.14.");
                    self.push_diagnostic(diagnostic);
                }
            }
        } else {
            match text.parse::<i64>() {
                Ok(value) => self.push_token(TokenKind::Int(value), span),
                Err(_) => {
                    let diagnostic = Diagnostic::error(
                        format!("Integer literal '{text}' out of range"),
                        span,
                    )
                    .with_suggestion(
                        "KuroLanguage integers currently support -9223372036854775808 to 9223372036854775807.",
                    );
                    self.push_diagnostic(diagnostic);
                }
            }
        }
    }

    fn consume_digits(&mut self) {
        while matches!(self.peek(), Some('0'..='9')) {
            self.advance();
        }
    }

    fn scan_ident_or_keyword(&mut self) {
        let start = self.pos;
        while matches!(self.peek(), Some(c) if is_ident_continue(c)) {
            self.advance();
        }
        let text = self.source[start as usize..self.pos as usize].to_string();
        let span = self.span_at(start, self.pos);
        let kind = match text.as_str() {
            "Func" => TokenKind::Func,
            "Var" => TokenKind::Var,
            "Const" => TokenKind::Const,
            "If" => TokenKind::If,
            "Else" => TokenKind::Else,
            "While" => TokenKind::While,
            "For" => TokenKind::For,
            "Foreach" => TokenKind::Foreach,
            "Return" => TokenKind::Return,
            "Break" => TokenKind::Break,
            "Continue" => TokenKind::Continue,
            "To" => TokenKind::To,
            "In" => TokenKind::In,
            "true" => TokenKind::True,
            "false" => TokenKind::False,
            "null" => TokenKind::Null,
            _ => TokenKind::Ident(text),
        };
        self.push_token(kind, span);
    }

    fn scan_operator_or_punct(&mut self, ch: char) {
        let start = self.pos;
        self.advance();
        let kind = match ch {
            '+' => TokenKind::Plus,
            '-' => TokenKind::Minus,
            '*' => TokenKind::Star,
            '/' => TokenKind::Slash,
            '%' => TokenKind::Percent,
            '(' => {
                self.bracket_depth += 1;
                TokenKind::LParen
            }
            ')' => {
                self.bracket_depth = self.bracket_depth.saturating_sub(1);
                TokenKind::RParen
            }
            '{' => TokenKind::LBrace,
            '}' => TokenKind::RBrace,
            '[' => {
                self.bracket_depth += 1;
                TokenKind::LBracket
            }
            ']' => {
                self.bracket_depth = self.bracket_depth.saturating_sub(1);
                TokenKind::RBracket
            }
            ',' => TokenKind::Comma,
            '.' => TokenKind::Dot,
            '=' if self.peek() == Some('=') => {
                self.advance();
                TokenKind::EqEq
            }
            '=' => TokenKind::Eq,
            '!' if self.peek() == Some('=') => {
                self.advance();
                TokenKind::NotEq
            }
            '!' => TokenKind::Not,
            '<' if self.peek() == Some('=') => {
                self.advance();
                TokenKind::LtEq
            }
            '<' => TokenKind::Lt,
            '>' if self.peek() == Some('=') => {
                self.advance();
                TokenKind::GtEq
            }
            '>' => TokenKind::Gt,
            '&' if self.peek() == Some('&') => {
                self.advance();
                TokenKind::AndAnd
            }
            '|' if self.peek() == Some('|') => {
                self.advance();
                TokenKind::OrOr
            }
            _ => {
                let span = self.span_at(start, self.pos);
                let diagnostic =
                    Diagnostic::error(format!("Unexpected character '{ch}'"), span)
                        .with_suggestion("Remove this character or check for a typo.");
                self.push_diagnostic(diagnostic);
                return;
            }
        };
        let span = self.span_at(start, self.pos);
        self.push_token(kind, span);
    }
}

fn is_ident_start(c: char) -> bool {
    c.is_ascii_alphabetic() || c == '_'
}

fn is_ident_continue(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '_'
}

#[cfg(test)]
mod tests {
    use super::*;
    use kuro_source::SourceMap;

    fn lex(src: &str) -> (Vec<TokenKind>, Diagnostics) {
        let mut sources = SourceMap::new();
        let id = sources.add_file("test.kr", src);
        let (tokens, diagnostics) = Lexer::new(id, src).tokenize();
        (tokens.into_iter().map(|t| t.kind).collect(), diagnostics)
    }

    #[test]
    fn keywords_and_identifiers() {
        let (kinds, diagnostics) = lex(
            "Func Var Const If Else While For Foreach Return Break Continue To In true false null myVar",
        );
        assert!(diagnostics.is_empty());
        assert_eq!(
            kinds,
            vec![
                TokenKind::Func,
                TokenKind::Var,
                TokenKind::Const,
                TokenKind::If,
                TokenKind::Else,
                TokenKind::While,
                TokenKind::For,
                TokenKind::Foreach,
                TokenKind::Return,
                TokenKind::Break,
                TokenKind::Continue,
                TokenKind::To,
                TokenKind::In,
                TokenKind::True,
                TokenKind::False,
                TokenKind::Null,
                TokenKind::Ident("myVar".to_string()),
                TokenKind::Eof,
            ]
        );
    }

    #[test]
    fn stdlib_names_are_plain_identifiers() {
        let (kinds, diagnostics) = lex("Console.Print()");
        assert!(diagnostics.is_empty());
        assert_eq!(
            kinds,
            vec![
                TokenKind::Ident("Console".to_string()),
                TokenKind::Dot,
                TokenKind::Ident("Print".to_string()),
                TokenKind::LParen,
                TokenKind::RParen,
                TokenKind::Eof,
            ]
        );
    }

    #[test]
    fn newline_terminates_statements() {
        let (kinds, diagnostics) = lex("Var x = 1\nVar y = 2");
        assert!(diagnostics.is_empty());
        assert_eq!(
            kinds,
            vec![
                TokenKind::Var,
                TokenKind::Ident("x".to_string()),
                TokenKind::Eq,
                TokenKind::Int(1),
                TokenKind::Newline,
                TokenKind::Var,
                TokenKind::Ident("y".to_string()),
                TokenKind::Eq,
                TokenKind::Int(2),
                TokenKind::Eof,
            ]
        );
    }

    #[test]
    fn blank_lines_coalesce_into_one_newline() {
        let (kinds, _) = lex("Var x = 1\n\n\nVar y = 2");
        let newline_count = kinds.iter().filter(|k| **k == TokenKind::Newline).count();
        assert_eq!(newline_count, 1);
    }

    #[test]
    fn newline_suppressed_inside_parens_and_brackets() {
        let (kinds, diagnostics) = lex("Console.Print(\n    x\n)\nVar list = [\n    1,\n    2\n]");
        assert!(diagnostics.is_empty());
        // Exactly one Newline: the one after the call closes, before `Var`.
        let newline_count = kinds.iter().filter(|k| **k == TokenKind::Newline).count();
        assert_eq!(newline_count, 1);
        assert!(kinds.contains(&TokenKind::LBracket));
        assert!(kinds.contains(&TokenKind::RBracket));
    }

    #[test]
    fn newline_not_suppressed_inside_braces() {
        // A block body's statements must still terminate at newlines.
        let (kinds, diagnostics) = lex("Func Main() {\n    Var x = 1\n}");
        assert!(diagnostics.is_empty());
        let newline_count = kinds.iter().filter(|k| **k == TokenKind::Newline).count();
        assert_eq!(newline_count, 2);
    }

    #[test]
    fn line_and_block_comments_are_preserved() {
        let (kinds, diagnostics) = lex("Var x = 1 // set x\n/* block */ Var y = 2");
        assert!(diagnostics.is_empty());
        assert!(kinds.contains(&TokenKind::LineComment("// set x".to_string())));
        assert!(kinds.contains(&TokenKind::BlockComment("/* block */".to_string())));
    }

    #[test]
    fn string_literal_with_escapes() {
        let (kinds, diagnostics) = lex(r#""Hello\nKuro""#);
        assert!(diagnostics.is_empty());
        assert_eq!(
            kinds,
            vec![TokenKind::Str("Hello\nKuro".to_string()), TokenKind::Eof]
        );
    }

    #[test]
    fn unterminated_string_reports_error_and_recovers() {
        let (kinds, diagnostics) = lex("Var x = \"oops\nVar y = 1");
        assert!(diagnostics.has_errors());
        // Lexing continues after the error: the next line is still tokenized.
        assert!(kinds.contains(&TokenKind::Var));
        assert!(kinds.contains(&TokenKind::Ident("y".to_string())));
    }

    #[test]
    fn unknown_escape_reports_error_and_recovers() {
        let (kinds, diagnostics) = lex(r#""bad\qescape""#);
        assert!(diagnostics.has_errors());
        assert_eq!(
            kinds,
            vec![TokenKind::Str("badqescape".to_string()), TokenKind::Eof]
        );
    }

    #[test]
    fn number_literals() {
        let (kinds, diagnostics) = lex("42 3.14");
        assert!(diagnostics.is_empty());
        assert_eq!(
            kinds,
            vec![TokenKind::Int(42), TokenKind::Float(3.14), TokenKind::Eof]
        );
    }

    #[test]
    fn operators() {
        let (kinds, diagnostics) = lex("== != <= >= < > && || ! = + - * / %");
        assert!(diagnostics.is_empty());
        assert_eq!(
            kinds,
            vec![
                TokenKind::EqEq,
                TokenKind::NotEq,
                TokenKind::LtEq,
                TokenKind::GtEq,
                TokenKind::Lt,
                TokenKind::Gt,
                TokenKind::AndAnd,
                TokenKind::OrOr,
                TokenKind::Not,
                TokenKind::Eq,
                TokenKind::Plus,
                TokenKind::Minus,
                TokenKind::Star,
                TokenKind::Slash,
                TokenKind::Percent,
                TokenKind::Eof,
            ]
        );
    }

    #[test]
    fn unexpected_character_reports_error_and_recovers() {
        let (kinds, diagnostics) = lex("Var x = 1 @ Var y = 2");
        assert!(diagnostics.has_errors());
        assert!(kinds.contains(&TokenKind::Ident("y".to_string())));
    }
}
