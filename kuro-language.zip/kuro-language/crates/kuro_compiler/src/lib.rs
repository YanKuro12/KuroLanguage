//! Native object compiler for KuroLanguage.
//!
//! The compiler consumes the existing Kuro AST and semantic contract and
//! emits a native object file through Cranelift. Linking is intentionally a
//! separate concern: Linux and Android can use different linker drivers while
//! sharing the same code generator.
//!
//! The current backend deliberately supports the value types that have a
//! direct, stable native representation: Int, Float, and Bool. String and
//! standard-library calls are rejected with compiler diagnostics until their
//! runtime ABI is formally specified.

mod codegen;
mod compiler;
mod error;
mod target;

pub use compiler::{CompileOptions, Compiler, ObjectFile};
pub use error::CompileError;
pub use target::{Target, TargetArch, TargetPlatform};

/// Compile a semantically valid Kuro program into a native object file for
/// the requested target.
pub fn compile(
    program: &kuro_ast::Program,
    options: &CompileOptions,
) -> Result<ObjectFile, kuro_diagnostics::Diagnostics> {
    Compiler::new(options.clone()).compile(program)
}
