use crate::codegen::FunctionCodegen;
use crate::error::CompileError;
use crate::target::Target;
use cranelift::module::{default_libcall_names, Module};
use cranelift::object::{ObjectBuilder, ObjectModule};
use kuro_ast::{Item, Program};
use kuro_diagnostics::{Diagnostic, Diagnostics};

/// Options controlling one compilation.
#[derive(Debug, Clone)]
pub struct CompileOptions {
    pub target: Target,
    pub optimization_level: OptimizationLevel,
}

impl Default for CompileOptions {
    fn default() -> Self {
        Self {
            target: Target::host().unwrap_or(Target::LINUX_X86_64),
            optimization_level: OptimizationLevel::Speed,
        }
    }
}

/// Cranelift optimization preference.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OptimizationLevel {
    None,
    Speed,
    SpeedAndSize,
}

impl OptimizationLevel {
    fn as_cranelift(self) -> &'static str {
        match self {
            Self::None => "none",
            Self::Speed => "speed",
            Self::SpeedAndSize => "speed_and_size",
        }
    }
}

/// Finished native object bytes.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ObjectFile {
    pub target: Target,
    pub bytes: Vec<u8>,
}

/// Kuro native compiler.
#[derive(Debug, Clone)]
pub struct Compiler {
    options: CompileOptions,
}

impl Compiler {
    pub fn new(options: CompileOptions) -> Self {
        Self { options }
    }

    pub fn options(&self) -> &CompileOptions {
        &self.options
    }

    /// Runs semantic analysis first, then lowers the program into Cranelift
    /// and finishes an object file.
    pub fn compile(&self, program: &Program) -> Result<ObjectFile, Diagnostics> {
        let semantic = kuro_semantic::analyze(program);
        if semantic.has_errors() {
            return Err(semantic);
        }

        let mut diagnostics = Diagnostics::new();

        if let Err(error) = self.reject_unsupported_surface(program) {
            diagnostics.push(error.diagnostic(program.span));
            return Err(diagnostics);
        }

        let isa = match self.make_isa() {
            Ok(isa) => isa,
            Err(error) => {
                diagnostics.push(error.diagnostic(program.span));
                return Err(diagnostics);
            }
        };

        let mut builder =
            match ObjectBuilder::new(isa, "kuro_module", default_libcall_names()) {
                Ok(builder) => builder,
                Err(error) => {
                    diagnostics.push(
                        CompileError::Backend(error.to_string()).diagnostic(program.span),
                    );
                    return Err(diagnostics);
                }
            };

        builder.per_function_section(true);
        let mut module = ObjectModule::new(builder);

        let mut codegen = FunctionCodegen::new(&mut module, self.options.optimization_level);
        if let Err(error) = codegen.declare_functions(program) {
            diagnostics.push(error.diagnostic(program.span));
            return Err(diagnostics);
        }

        for item in &program.items {
            if let Item::Function(function) = item {
                if let Err(error) = codegen.define_function(function) {
                    diagnostics.push(error.diagnostic(function.span));
                    return Err(diagnostics);
                }
            }
        }

        let product = module.finish();
        let bytes = product.object.write().map_err(|error| {
            let mut diagnostics = Diagnostics::new();
            diagnostics.push(
                CompileError::Backend(format!("Failed to write object file: {error}"))
                    .diagnostic(program.span),
            );
            diagnostics
        })?;

        Ok(ObjectFile {
            target: self.options.target,
            bytes,
        })
    }

    fn make_isa(
        &self,
    ) -> Result<Box<dyn cranelift::codegen::isa::TargetIsa>, CompileError> {
        let triple = self.options.target.triple();
        let mut flags_builder = cranelift::codegen::settings::builder();

        flags_builder
            .set("opt_level", self.options.optimization_level.as_cranelift())
            .map_err(|e| CompileError::Backend(e.to_string()))?;

        flags_builder
            .set("is_pic", "true")
            .map_err(|e| CompileError::Backend(e.to_string()))?;

        let flags = cranelift::codegen::settings::Flags::new(flags_builder);
        let builder = cranelift::codegen::isa::lookup(triple)
            .map_err(|e| CompileError::InvalidTarget(e.to_string()))?;

        builder
            .finish(flags)
            .map_err(|e| CompileError::Backend(e.to_string()))
    }

    fn reject_unsupported_surface(&self, program: &Program) -> Result<(), CompileError> {
        for item in &program.items {
            match item {
                Item::Const(c) => self.reject_expr(&c.value)?,
                Item::Function(f) => {
                    for stmt in &f.body.statements {
                        self.reject_stmt(stmt)?;
                    }
                }
            }
        }
        Ok(())
    }

    fn reject_stmt(&self, stmt: &kuro_ast::Stmt) -> Result<(), CompileError> {
        use kuro_ast::Stmt;

        match stmt {
            Stmt::VarDecl(v) => self.reject_expr(&v.value)?,
            Stmt::ConstDecl(c) => self.reject_expr(&c.value)?,
            Stmt::Assign(a) => {
                self.reject_expr(&a.target)?;
                self.reject_expr(&a.value)?;
            }
            Stmt::Expr(e) => self.reject_expr(&e.expr)?,
            Stmt::If(i) => self.reject_if(i)?,
            Stmt::While(w) => {
                self.reject_expr(&w.condition)?;
                self.reject_block(&w.body)?;
            }
            Stmt::For(f) => {
                self.reject_expr(&f.start)?;
                self.reject_expr(&f.end)?;
                self.reject_block(&f.body)?;
            }
            Stmt::Foreach(f) => {
                self.reject_expr(&f.iterable)?;
                return Err(CompileError::Unsupported {
                    feature: "Foreach".to_string(),
                    span: f.span,
                });
            }
            Stmt::Return(r) => {
                if let Some(value) = &r.value {
                    self.reject_expr(value)?;
                }
            }
            Stmt::Break(_) | Stmt::Continue(_) => {}
            Stmt::Block(block) => self.reject_block(block)?,
        }
        Ok(())
    }

    fn reject_if(&self, stmt: &kuro_ast::IfStmt) -> Result<(), CompileError> {
        self.reject_expr(&stmt.condition)?;
        self.reject_block(&stmt.then_branch)?;

        match &stmt.else_branch {
            Some(kuro_ast::ElseBranch::ElseIf(nested)) => self.reject_if(nested),
            Some(kuro_ast::ElseBranch::Else(block)) => self.reject_block(block),
            None => Ok(()),
        }
    }

    fn reject_block(&self, block: &kuro_ast::Block) -> Result<(), CompileError> {
        for stmt in &block.statements {
            self.reject_stmt(stmt)?;
        }
        Ok(())
    }

    fn reject_expr(&self, expr: &kuro_ast::Expr) -> Result<(), CompileError> {
        use kuro_ast::ExprKind;

        match &expr.kind {
            ExprKind::StringLiteral(_) | ExprKind::NullLiteral => {
                Err(CompileError::Unsupported {
                    feature: "String/null values".to_string(),
                    span: expr.span,
                })
            }
            ExprKind::Call(callee, args) => {
                self.reject_expr(callee)?;
                for arg in args {
                    self.reject_expr(arg)?;
                }
                if matches!(callee.kind, ExprKind::Member(_, _)) {
                    return Err(CompileError::Unsupported {
                        feature: "standard-library calls".to_string(),
                        span: expr.span,
                    });
                }
                Ok(())
            }
            ExprKind::Member(object, _) => {
                self.reject_expr(object)?;
                Err(CompileError::Unsupported {
                    feature: "member values".to_string(),
                    span: expr.span,
                })
            }
            ExprKind::Binary(left, _, right) => {
                self.reject_expr(left)?;
                self.reject_expr(right)
            }
            ExprKind::Unary(_, operand) => self.reject_expr(operand),
            ExprKind::Ident(_) | ExprKind::IntLiteral(_) | ExprKind::FloatLiteral(_)
            | ExprKind::BoolLiteral(_) => Ok(()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use kuro_lexer::Lexer;
    use kuro_source::SourceMap;

    fn parse_source(src: &str) -> Program {
        let mut sources = SourceMap::new();
        let id = sources.add_file("test.kr", src);
        let (tokens, lex) = Lexer::new(id, src).tokenize();
        assert!(lex.is_empty(), "{lex:?}");
        let (program, parse) = kuro_parser::parse(&tokens);
        assert!(parse.is_empty(), "{parse:?}");
        program
    }

    #[test]
    fn compiles_a_simple_integer_program_to_an_object() {
        let program = parse_source("Func Main() {\n    Var x = 1 + 2\n}");
        let result = Compiler::new(CompileOptions {
            target: Target::LINUX_X86_64,
            optimization_level: OptimizationLevel::None,
        })
        .compile(&program);

        assert!(result.is_ok(), "{result:?}");
        assert!(!result.unwrap().bytes.is_empty());
    }

    #[test]
    fn rejects_foreach_until_collection_types_exist() {
        let program = parse_source(
            "Func Main() {\n    Foreach item In list {\n        Break\n    }\n}",
        );
        let result = Compiler::new(CompileOptions::default()).compile(&program);
        assert!(result.is_err());
    }

    #[test]
    fn rejects_string_until_runtime_abi_exists() {
        let program = parse_source(
            "Func Main() {\n    Var x = \"hello\"\n}",
        );
        let result = Compiler::new(CompileOptions::default()).compile(&program);
        assert!(result.is_err());
    }
}
