use std::fmt;
use target_lexicon::Triple;

/// Operating system targeted by the native compiler.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TargetPlatform {
    Linux,
    Android,
}

impl TargetPlatform {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Linux => "linux",
            Self::Android => "android",
        }
    }
}

impl fmt::Display for TargetPlatform {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// CPU architecture supported by the first native backend.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TargetArch {
    X86_64,
    Aarch64,
}

impl TargetArch {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::X86_64 => "x86_64",
            Self::Aarch64 => "aarch64",
        }
    }
}

impl fmt::Display for TargetArch {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Concrete native compilation target.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Target {
    pub platform: TargetPlatform,
    pub arch: TargetArch,
}

impl Target {
    pub const LINUX_X86_64: Self = Self {
        platform: TargetPlatform::Linux,
        arch: TargetArch::X86_64,
    };

    pub const LINUX_AARCH64: Self = Self {
        platform: TargetPlatform::Linux,
        arch: TargetArch::Aarch64,
    };

    pub const ANDROID_AARCH64: Self = Self {
        platform: TargetPlatform::Android,
        arch: TargetArch::Aarch64,
    };

    pub fn host() -> Option<Self> {
        let arch = match std::env::consts::ARCH {
            "x86_64" => TargetArch::X86_64,
            "aarch64" => TargetArch::Aarch64,
            _ => return None,
        };

        let platform = match std::env::consts::OS {
            "linux" => TargetPlatform::Linux,
            "android" => TargetPlatform::Android,
            _ => return None,
        };

        Some(Self { platform, arch })
    }

    pub fn triple(self) -> Triple {
        match (self.platform, self.arch) {
            (TargetPlatform::Linux, TargetArch::X86_64) => {
                "x86_64-unknown-linux-gnu".parse().expect("static target triple")
            }
            (TargetPlatform::Linux, TargetArch::Aarch64) => {
                "aarch64-unknown-linux-gnu".parse().expect("static target triple")
            }
            (TargetPlatform::Android, TargetArch::Aarch64) => {
                "aarch64-linux-android".parse().expect("static target triple")
            }
        }
    }
}

impl fmt::Display for Target {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}-{}", self.arch, self.platform)
    }
}
