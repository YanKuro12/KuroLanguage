use kuro_diagnostics::Diagnostic;
use kuro_source::Span;
use std::fmt;

/// A compiler-stage failure that is not itself a language semantic error.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CompileError {
    Backend(String),
    Unsupported { feature: String, span: Span },
    InvalidTarget(String),
}

impl CompileError {
    pub(crate) fn diagnostic(self, span: Span) -> Diagnostic {
        match self {
            Self::Backend(message) => Diagnostic::error(message, span),
            Self::InvalidTarget(message) => Diagnostic::error(message, span),
            Self::Unsupported { feature, span } => Diagnostic::error(
                format!("Compiler does not support {feature} yet"),
                span,
            ),
        }
    }
}

impl fmt::Display for CompileError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Backend(message) => f.write_str(message),
            Self::InvalidTarget(message) => f.write_str(message),
            Self::Unsupported { feature, .. } => {
                write!(f, "Compiler does not support {feature} yet")
            }
        }
    }
}

impl std::error::Error for CompileError {}
