use crate::compiler::OptimizationLevel;
use crate::error::CompileError;
use cranelift::codegen::ir::{
    condcodes::{FloatCC, IntCC},
    types,
};
use cranelift::module::{FuncId, Linkage, Module, ModuleError};
use cranelift::object::ObjectModule;
use cranelift::prelude::*;
use kuro_ast::{
    BinaryOp, Block, ElseBranch, Expr, ExprKind, FunctionDecl, IfStmt, Item, Stmt, UnaryOp,
};
use std::collections::HashMap;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum KType {
    Int,
    Float,
    Bool,
    Void,
}

impl KType {
    fn clif(self) -> Option<Type> {
        match self {
            Self::Int => Some(types::I64),
            Self::Float => Some(types::F64),
            Self::Bool => Some(types::I8),
            Self::Void => None,
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct Binding {
    var: Variable,
    ty: KType,
}

#[derive(Debug, Clone, Copy)]
struct FunctionInfo {
    id: FuncId,
    return_type: KType,
}

pub(crate) struct FunctionCodegen<'m> {
    module: &'m mut ObjectModule,
    ctx: cranelift::codegen::Context,
    builder_ctx: FunctionBuilderContext,
    functions: HashMap<String, FunctionInfo>,
    optimization_level: OptimizationLevel,
}

impl<'m> FunctionCodegen<'m> {
    pub(crate) fn new(
        module: &'m mut ObjectModule,
        optimization_level: OptimizationLevel,
    ) -> Self {
        let ctx = module.make_context();
        Self {
            module,
            ctx,
            builder_ctx: FunctionBuilderContext::new(),
            functions: HashMap::new(),
            optimization_level,
        }
    }

    pub(crate) fn declare_functions(
        &mut self,
        program: &kuro_ast::Program,
    ) -> Result<(), CompileError> {
        for item in &program.items {
            let Item::Function(function) = item else {
                continue;
            };

            let mut signature = self.module.make_signature();

            for param in &function.params {
                let ty = resolve_annotation(&param.type_annotation.name)?;
                let clif_ty = ty.clif().ok_or_else(|| {
                    CompileError::Backend(format!(
                        "Parameter '{}' cannot have type Void",
                        param.name
                    ))
                })?;
                signature.params.push(AbiParam::new(clif_ty));
            }

            let return_type = function
                .return_type
                .as_ref()
                .map(|annotation| resolve_annotation(&annotation.name))
                .transpose()?
                .unwrap_or(KType::Void);

            if let Some(clif_ty) = return_type.clif() {
                signature.returns.push(AbiParam::new(clif_ty));
            }

            let linkage = if function.name == "Main" {
                Linkage::Export
            } else {
                Linkage::Local
            };

            let id = self
                .module
                .declare_function(&function.name, linkage, &signature)
                .map_err(module_error)?;

            self.functions.insert(
                function.name.clone(),
                FunctionInfo { id, return_type },
            );
        }

        Ok(())
    }

    pub(crate) fn define_function(
        &mut self,
        function: &FunctionDecl,
    ) -> Result<(), CompileError> {
        let info = *self.functions.get(&function.name).ok_or_else(|| {
            CompileError::Backend(format!("Function '{}' was not declared", function.name))
        })?;

        self.ctx.clear();
        self.ctx.func.signature = self.module.declarations()[info.id].signature.clone();

        let mut builder =
            FunctionBuilder::new(&mut self.ctx.func, &mut self.builder_ctx);

        let entry = builder.create_block();
        builder.append_block_params_for_function_params(entry);
        builder.switch_to_block(entry);

        let mut scopes: Vec<HashMap<String, Binding>> = vec![HashMap::new()];

        for (index, param) in function.params.iter().enumerate() {
            let ty = resolve_annotation(&param.type_annotation.name)?;
            let var = builder.declare_var(ty.clif().unwrap());
            let value = builder.block_params(entry)[index];
            builder.def_var(var, value);
            scopes[0].insert(param.name.clone(), Binding { var, ty });
        }

        let mut loops = Vec::new();
        let signal = compile_block(
            &mut builder,
            &mut scopes,
            &mut loops,
            &self.functions,
            self.module,
            &function.body,
        )?;

        if !signal.terminated {
            if info.return_type == KType::Void {
                builder.ins().return_(&[]);
            } else {
                // Kuro's semantic stage currently does not require every
                // control-flow path to return. Preserve that contract by
                // returning the type's zero value on a fallthrough path.
                let zero = zero_value(&mut builder, info.return_type);
                builder.ins().return_(&[zero]);
            }
        }

        builder.seal_all_blocks();
        builder.finalize();

        self.module
            .define_function(info.id, &mut self.ctx)
            .map_err(module_error)?;
        self.module.clear_context(&mut self.ctx);

        let _ = self.optimization_level;
        Ok(())
    }
}

#[derive(Debug, Clone, Copy)]
struct LoopTargets {
    break_block: Block,
    continue_block: Block,
}

#[derive(Debug, Clone, Copy)]
struct Signal {
    terminated: bool,
}

fn module_error(error: ModuleError) -> CompileError {
    CompileError::Backend(error.to_string())
}

fn resolve_annotation(name: &str) -> Result<KType, CompileError> {
    match name {
        "Int" => Ok(KType::Int),
        "Float" => Ok(KType::Float),
        "Bool" => Ok(KType::Bool),
        "Void" => Ok(KType::Void),
        other => Err(CompileError::Backend(format!(
            "Unsupported type '{other}' in native backend"
        ))),
    }
}

fn lookup(
    scopes: &[HashMap<String, Binding>],
    name: &str,
) -> Result<Binding, CompileError> {
    for scope in scopes.iter().rev() {
        if let Some(binding) = scope.get(name) {
            return Ok(*binding);
        }
    }

    Err(CompileError::Backend(format!(
        "Internal compiler error: unresolved identifier '{name}'"
    )))
}

fn infer_expr_type(
    expr: &Expr,
    scopes: &[HashMap<String, Binding>],
    functions: &HashMap<String, FunctionInfo>,
) -> Result<KType, CompileError> {
    match &expr.kind {
        ExprKind::IntLiteral(_) => Ok(KType::Int),
        ExprKind::FloatLiteral(_) => Ok(KType::Float),
        ExprKind::BoolLiteral(_) => Ok(KType::Bool),
        ExprKind::Ident(name) => Ok(lookup(scopes, name)?.ty),
        ExprKind::Unary(op, operand) => match op {
            UnaryOp::Neg => infer_expr_type(operand, scopes, functions),
            UnaryOp::Not => Ok(KType::Bool),
        },
        ExprKind::Binary(left, op, right) => {
            let left_ty = infer_expr_type(left, scopes, functions)?;
            let right_ty = infer_expr_type(right, scopes, functions)?;

            match op {
                BinaryOp::Eq
                | BinaryOp::NotEq
                | BinaryOp::Lt
                | BinaryOp::Gt
                | BinaryOp::LtEq
                | BinaryOp::GtEq
                | BinaryOp::And
                | BinaryOp::Or => Ok(KType::Bool),
                BinaryOp::Add
                | BinaryOp::Sub
                | BinaryOp::Mul
                | BinaryOp::Div
                | BinaryOp::Mod => {
                    if left_ty == KType::Float || right_ty == KType::Float {
                        Ok(KType::Float)
                    } else {
                        Ok(KType::Int)
                    }
                }
            }
        }
        ExprKind::Call(callee, _) => {
            let ExprKind::Ident(name) = &callee.kind else {
                return Err(CompileError::Backend(
                    "Only direct user-function calls have a native type".into(),
                ));
            };

            functions
                .get(name)
                .map(|info| info.return_type)
                .ok_or_else(|| CompileError::Backend(format!("Unresolved function '{name}'")))
        }
        ExprKind::StringLiteral(_) | ExprKind::NullLiteral | ExprKind::Member(_, _) => {
            Err(CompileError::Backend("Unsupported expression type".into()))
        }
    }
}

fn zero_value(builder: &mut FunctionBuilder<'_>, ty: KType) -> Value {
    match ty {
        KType::Int | KType::Bool => builder.ins().iconst(ty.clif().unwrap(), 0),
        KType::Float => builder.ins().f64const(0.0),
        KType::Void => unreachable!(),
    }
}

fn compile_block(
    builder: &mut FunctionBuilder<'_>,
    scopes: &mut Vec<HashMap<String, Binding>>,
    loops: &mut Vec<LoopTargets>,
    functions: &HashMap<String, FunctionInfo>,
    module: &mut ObjectModule,
    block: &Block,
) -> Result<Signal, CompileError> {
    scopes.push(HashMap::new());

    let mut terminated = false;
    for stmt in &block.statements {
        if terminated {
            break;
        }

        terminated =
            compile_stmt(builder, scopes, loops, functions, module, stmt)?.terminated;
    }

    scopes.pop();
    Ok(Signal { terminated })
}

fn compile_stmt(
    builder: &mut FunctionBuilder<'_>,
    scopes: &mut Vec<HashMap<String, Binding>>,
    loops: &mut Vec<LoopTargets>,
    functions: &HashMap<String, FunctionInfo>,
    module: &mut ObjectModule,
    stmt: &Stmt,
) -> Result<Signal, CompileError> {
    match stmt {
        Stmt::VarDecl(var) => {
            let ty = infer_expr_type(&var.value, scopes, functions)?;
            let value = compile_expr(builder, scopes, functions, module, &var.value)?;
            let variable = builder.declare_var(ty.clif().ok_or_else(|| {
                CompileError::Backend("Void variable".into())
            })?);
            builder.def_var(variable, value);
            scopes.last_mut().unwrap().insert(
                var.name.clone(),
                Binding { var: variable, ty },
            );
            Ok(Signal { terminated: false })
        }

        Stmt::ConstDecl(decl) => {
            let ty = infer_expr_type(&decl.value, scopes, functions)?;
            let value = compile_expr(builder, scopes, functions, module, &decl.value)?;
            let variable = builder.declare_var(ty.clif().ok_or_else(|| {
                CompileError::Backend("Void constant".into())
            })?);
            builder.def_var(variable, value);
            scopes.last_mut().unwrap().insert(
                decl.name.clone(),
                Binding { var: variable, ty },
            );
            Ok(Signal { terminated: false })
        }

        Stmt::Assign(assign) => {
            let ExprKind::Ident(name) = &assign.target.kind else {
                return Err(CompileError::Backend(
                    "Only identifier assignment is supported by the native backend".into(),
                ));
            };

            let binding = lookup(scopes, name)?;
            let value = compile_expr(builder, scopes, functions, module, &assign.value)?;
            builder.def_var(binding.var, value);
            Ok(Signal { terminated: false })
        }

        Stmt::Expr(expr_stmt) => {
            let _ = compile_expr(builder, scopes, functions, module, &expr_stmt.expr)?;
            Ok(Signal { terminated: false })
        }

        Stmt::If(if_stmt) => {
            compile_if(builder, scopes, loops, functions, module, if_stmt)
        }

        Stmt::While(stmt) => {
            compile_while(builder, scopes, loops, functions, module, stmt)
        }

        Stmt::For(stmt) => {
            compile_for(builder, scopes, loops, functions, module, stmt)
        }

        Stmt::Foreach(stmt) => Err(CompileError::Unsupported {
            feature: "Foreach".into(),
            span: stmt.span,
        }),

        Stmt::Return(ret) => {
            if let Some(value) = &ret.value {
                let value = compile_expr(builder, scopes, functions, module, value)?;
                builder.ins().return_(&[value]);
            } else {
                builder.ins().return_(&[]);
            }

            Ok(Signal { terminated: true })
        }

        Stmt::Break(span) => {
            let Some(target) = loops.last().copied() else {
                return Err(CompileError::Backend(format!(
                    "Internal compiler error: Break outside loop at {span:?}"
                )));
            };

            builder.ins().jump(target.break_block, &[]);
            Ok(Signal { terminated: true })
        }

        Stmt::Continue(span) => {
            let Some(target) = loops.last().copied() else {
                return Err(CompileError::Backend(format!(
                    "Internal compiler error: Continue outside loop at {span:?}"
                )));
            };

            builder.ins().jump(target.continue_block, &[]);
            Ok(Signal { terminated: true })
        }

        Stmt::Block(block) => {
            compile_block(builder, scopes, loops, functions, module, block)
        }
    }
}

fn compile_if(
    builder: &mut FunctionBuilder<'_>,
    scopes: &mut Vec<HashMap<String, Binding>>,
    loops: &mut Vec<LoopTargets>,
    functions: &HashMap<String, FunctionInfo>,
    module: &mut ObjectModule,
    stmt: &IfStmt,
) -> Result<Signal, CompileError> {
    let then_block = builder.create_block();
    let else_block = builder.create_block();
    let join_block = builder.create_block();

    let condition = compile_expr(builder, scopes, functions, module, &stmt.condition)?;
    builder
        .ins()
        .brif(condition, then_block, &[], else_block, &[]);

    builder.switch_to_block(then_block);
    let then_signal =
        compile_block(builder, scopes, loops, functions, module, &stmt.then_branch)?;
    if !then_signal.terminated {
        builder.ins().jump(join_block, &[]);
    }

    builder.switch_to_block(else_block);
    let else_signal = match &stmt.else_branch {
        Some(ElseBranch::ElseIf(nested)) => {
            compile_if(builder, scopes, loops, functions, module, nested)?
        }
        Some(ElseBranch::Else(block)) => {
            compile_block(builder, scopes, loops, functions, module, block)?
        }
        None => Signal { terminated: false },
    };

    if !else_signal.terminated {
        builder.ins().jump(join_block, &[]);
    }

    if then_signal.terminated && else_signal.terminated {
        Ok(Signal { terminated: true })
    } else {
        builder.switch_to_block(join_block);
        Ok(Signal { terminated: false })
    }
}

fn compile_while(
    builder: &mut FunctionBuilder<'_>,
    scopes: &mut Vec<HashMap<String, Binding>>,
    loops: &mut Vec<LoopTargets>,
    functions: &HashMap<String, FunctionInfo>,
    module: &mut ObjectModule,
    stmt: &kuro_ast::WhileStmt,
) -> Result<Signal, CompileError> {
    let header = builder.create_block();
    let body = builder.create_block();
    let exit = builder.create_block();

    builder.ins().jump(header, &[]);
    builder.switch_to_block(header);

    let condition = compile_expr(builder, scopes, functions, module, &stmt.condition)?;
    builder.ins().brif(condition, body, &[], exit, &[]);

    builder.switch_to_block(body);
    loops.push(LoopTargets {
        break_block: exit,
        continue_block: header,
    });
    let body_signal =
        compile_block(builder, scopes, loops, functions, module, &stmt.body)?;
    loops.pop();

    if !body_signal.terminated {
        builder.ins().jump(header, &[]);
    }

    builder.switch_to_block(exit);
    Ok(Signal { terminated: false })
}

fn compile_for(
    builder: &mut FunctionBuilder<'_>,
    scopes: &mut Vec<HashMap<String, Binding>>,
    loops: &mut Vec<LoopTargets>,
    functions: &HashMap<String, FunctionInfo>,
    module: &mut ObjectModule,
    stmt: &kuro_ast::ForStmt,
) -> Result<Signal, CompileError> {
    let start = compile_expr(builder, scopes, functions, module, &stmt.start)?;
    let end = compile_expr(builder, scopes, functions, module, &stmt.end)?;

    let binding = builder.declare_var(types::I64);
    builder.def_var(binding, start);

    let header = builder.create_block();
    let body = builder.create_block();
    let latch = builder.create_block();
    let exit = builder.create_block();

    scopes.push(HashMap::new());
    scopes.last_mut().unwrap().insert(
        stmt.binding.clone(),
        Binding {
            var: binding,
            ty: KType::Int,
        },
    );

    builder.ins().jump(header, &[]);
    builder.switch_to_block(header);

    let current = builder.use_var(binding);
    let condition = builder.ins().icmp(IntCC::SignedLessThan, current, end);
    builder.ins().brif(condition, body, &[], exit, &[]);

    builder.switch_to_block(body);
    loops.push(LoopTargets {
        break_block: exit,
        continue_block: latch,
    });
    let body_signal =
        compile_block(builder, scopes, loops, functions, module, &stmt.body)?;
    loops.pop();

    if !body_signal.terminated {
        builder.ins().jump(latch, &[]);
    }

    builder.switch_to_block(latch);
    let current = builder.use_var(binding);
    let next = builder.ins().iadd_imm(current, 1);
    builder.def_var(binding, next);
    builder.ins().jump(header, &[]);

    builder.switch_to_block(exit);
    scopes.pop();

    Ok(Signal { terminated: false })
}

fn compile_expr(
    builder: &mut FunctionBuilder<'_>,
    scopes: &mut Vec<HashMap<String, Binding>>,
    functions: &HashMap<String, FunctionInfo>,
    module: &mut ObjectModule,
    expr: &Expr,
) -> Result<Value, CompileError> {
    match &expr.kind {
        ExprKind::IntLiteral(value) => {
            Ok(builder.ins().iconst(types::I64, *value))
        }

        ExprKind::FloatLiteral(value) => {
            Ok(builder.ins().f64const(*value))
        }

        ExprKind::BoolLiteral(value) => {
            Ok(builder.ins().iconst(types::I8, i64::from(*value)))
        }

        ExprKind::Ident(name) => {
            Ok(builder.use_var(lookup(scopes, name)?.var))
        }

        ExprKind::Unary(op, operand) => {
            let value = compile_expr(builder, scopes, functions, module, operand)?;
            match op {
                UnaryOp::Neg => {
                    if infer_expr_type(operand, scopes, functions)? == KType::Float {
                        Ok(builder.ins().fneg(value))
                    } else {
                        Ok(builder.ins().ineg(value))
                    }
                }
                UnaryOp::Not => {
                    let zero = builder.ins().iconst(types::I8, 0);
                    Ok(builder.ins().icmp(IntCC::Equal, value, zero))
                }
            }
        }

        ExprKind::Binary(left, op, right) => {
            if matches!(op, BinaryOp::And | BinaryOp::Or) {
                return compile_logical(
                    builder,
                    scopes,
                    functions,
                    module,
                    left,
                    *op,
                    right,
                );
            }

            let left_ty = infer_expr_type(left, scopes, functions)?;
            let result_ty = infer_expr_type(expr, scopes, functions)?;
            let lhs = compile_expr(builder, scopes, functions, module, left)?;
            let rhs = compile_expr(builder, scopes, functions, module, right)?;

            compile_binary(builder, lhs, rhs, *op, left_ty, result_ty, expr.span)
        }

        ExprKind::Call(callee, args) => {
            let ExprKind::Ident(name) = &callee.kind else {
                return Err(CompileError::Unsupported {
                    feature: "member/function-value calls".into(),
                    span: expr.span,
                });
            };

            let info = functions.get(name).copied().ok_or_else(|| {
                CompileError::Backend(format!("Unresolved function '{name}'"))
            })?;

            if info.return_type == KType::Void {
                return Err(CompileError::Backend(format!(
                    "Void function '{name}' cannot be used as a value"
                )));
            }

            let values = args
                .iter()
                .map(|arg| compile_expr(builder, scopes, functions, module, arg))
                .collect::<Result<Vec<_>, _>>()?;

            let func_ref = module.declare_func_in_func(info.id, builder.func);
            let call = builder.ins().call(func_ref, &values);

            builder
                .inst_results(call)
                .first()
                .copied()
                .ok_or_else(|| CompileError::Backend(format!(
                    "Function '{name}' produced no value"
                )))
        }

        ExprKind::StringLiteral(_) | ExprKind::NullLiteral | ExprKind::Member(_, _) => {
            Err(CompileError::Unsupported {
                feature: "this expression".into(),
                span: expr.span,
            })
        }
    }
}

fn compile_binary(
    builder: &mut FunctionBuilder<'_>,
    mut lhs: Value,
    mut rhs: Value,
    op: BinaryOp,
    operand_ty: KType,
    result_ty: KType,
    _span: kuro_source::Span,
) -> Result<Value, CompileError> {
    if result_ty == KType::Float {
        lhs = cast_numeric(builder, lhs, operand_ty);
        rhs = cast_numeric(builder, rhs, infer_rhs_type(builder, rhs));
    }

    match op {
        BinaryOp::Add => Ok(if result_ty == KType::Float {
            builder.ins().fadd(lhs, rhs)
        } else {
            builder.ins().iadd(lhs, rhs)
        }),

        BinaryOp::Sub => Ok(if result_ty == KType::Float {
            builder.ins().fsub(lhs, rhs)
        } else {
            builder.ins().isub(lhs, rhs)
        }),

        BinaryOp::Mul => Ok(if result_ty == KType::Float {
            builder.ins().fmul(lhs, rhs)
        } else {
            builder.ins().imul(lhs, rhs)
        }),

        BinaryOp::Div => Ok(if result_ty == KType::Float {
            builder.ins().fdiv(lhs, rhs)
        } else {
            builder.ins().sdiv(lhs, rhs)
        }),

        BinaryOp::Mod => Ok(if result_ty == KType::Float {
            builder.ins().frem(lhs, rhs)
        } else {
            builder.ins().srem(lhs, rhs)
        }),

        BinaryOp::Eq
        | BinaryOp::NotEq
        | BinaryOp::Lt
        | BinaryOp::Gt
        | BinaryOp::LtEq
        | BinaryOp::GtEq => {
            if result_ty != KType::Bool {
                return Err(CompileError::Backend(
                    "Internal compiler error: comparison did not produce Bool".into(),
                ));
            }

            if operand_ty == KType::Float {
                let cc = match op {
                    BinaryOp::Eq => FloatCC::Equal,
                    BinaryOp::NotEq => FloatCC::NotEqual,
                    BinaryOp::Lt => FloatCC::LessThan,
                    BinaryOp::Gt => FloatCC::GreaterThan,
                    BinaryOp::LtEq => FloatCC::LessThanOrEqual,
                    BinaryOp::GtEq => FloatCC::GreaterThanOrEqual,
                    _ => unreachable!(),
                };
                Ok(builder.ins().fcmp(cc, lhs, rhs))
            } else {
                let cc = match op {
                    BinaryOp::Eq => IntCC::Equal,
                    BinaryOp::NotEq => IntCC::NotEqual,
                    BinaryOp::Lt => IntCC::SignedLessThan,
                    BinaryOp::Gt => IntCC::SignedGreaterThan,
                    BinaryOp::LtEq => IntCC::SignedLessThanOrEqual,
                    BinaryOp::GtEq => IntCC::SignedGreaterThanOrEqual,
                    _ => unreachable!(),
                };
                Ok(builder.ins().icmp(cc, lhs, rhs))
            }
        }

        BinaryOp::And | BinaryOp::Or => unreachable!(),
    }
}

fn infer_rhs_type(builder: &FunctionBuilder<'_>, rhs: Value) -> KType {
    match builder.func.dfg.value_type(rhs) {
        ty if ty == types::F64 => KType::Float,
        ty if ty == types::I8 => KType::Bool,
        _ => KType::Int,
    }
}

fn cast_numeric(
    builder: &mut FunctionBuilder<'_>,
    value: Value,
    source: KType,
) -> Value {
    if source == KType::Int && builder.func.dfg.value_type(value) == types::I64 {
        builder.ins().fcvt_from_sint(types::F64, value)
    } else {
        value
    }
}

fn compile_logical(
    builder: &mut FunctionBuilder<'_>,
    scopes: &mut Vec<HashMap<String, Binding>>,
    functions: &HashMap<String, FunctionInfo>,
    module: &mut ObjectModule,
    left: &Expr,
    op: BinaryOp,
    right: &Expr,
) -> Result<Value, CompileError> {
    let left_value = compile_expr(builder, scopes, functions, module, left)?;

    let rhs_block = builder.create_block();
    let short_block = builder.create_block();
    let join_block = builder.create_block();

    let zero = builder.ins().iconst(types::I8, 0);
    let left_true = builder.ins().icmp(IntCC::NotEqual, left_value, zero);

    match op {
        BinaryOp::And => {
            builder.ins().brif(left_true, rhs_block, &[], short_block, &[]);
        }
        BinaryOp::Or => {
            builder.ins().brif(left_true, short_block, &[], rhs_block, &[]);
        }
        _ => unreachable!(),
    }

    builder.switch_to_block(short_block);
    let short_value =
        builder.ins().iconst(types::I8, if op == BinaryOp::And { 0 } else { 1 });
    builder.ins().jump(join_block, &[short_value]);

    builder.switch_to_block(rhs_block);
    let right_value = compile_expr(builder, scopes, functions, module, right)?;
    let right_bool = builder.ins().icmp(
        IntCC::NotEqual,
        right_value,
        builder.ins().iconst(types::I8, 0),
    );
    builder.ins().jump(join_block, &[right_bool]);

    builder.append_block_param(join_block, types::I8);
    builder.switch_to_block(join_block);

    Ok(builder.block_params(join_block)[0])
}
