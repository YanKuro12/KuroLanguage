use crate::value::Value;
use kuro_ast::{FunctionDecl, Item, Program};
use kuro_diagnostics::Diagnostic;
use std::collections::HashMap;
use std::io::{BufRead, Write};

mod builtins;
mod expr;
mod stmt;

/// What happened while executing a statement or block: either normal
/// completion, or a control-flow signal that needs to propagate up to
/// whichever enclosing construct handles it — a function call for
/// `Return`, a loop for `Break`/`Continue`.
#[derive(Debug)]
pub(crate) enum Signal {
    Normal,
    Return(Value),
    Break,
    Continue,
}

/// Runs a semantically-checked [`Program`].
///
/// Construct with [`Interpreter::new`], then call [`Interpreter::run`].
/// Unlike the lexer, parser, and semantic analyzer, execution does *not*
/// try to recover from a problem and keep going: a runtime error (e.g.
/// division by zero) stops the program at that point and is returned as
/// a single [`Diagnostic`], the same way the earlier stages report
/// problems — there's no "collect every runtime error" equivalent, since
/// later code's behavior generally depends on state a stopped-partway
/// execution can no longer meaningfully provide.
///
/// This crate assumes `program` already passed `kuro_semantic` — it
/// doesn't re-check names or types, only reports the runtime problems
/// that checking can't catch in advance (division by zero, a stdlib
/// conversion given a value it can't convert, and so on).
pub struct Interpreter<'a, W: Write, R: BufRead> {
    program: &'a Program,
    functions: HashMap<&'a str, &'a FunctionDecl>,
    globals: HashMap<String, Value>,
    scopes: Vec<HashMap<String, Value>>,
    stdout: W,
    stdin: R,
}

impl<'a, W: Write, R: BufRead> Interpreter<'a, W, R> {
    pub fn new(program: &'a Program, stdout: W, stdin: R) -> Self {
        let mut functions = HashMap::new();
        for item in &program.items {
            if let Item::Function(func) = item {
                functions.insert(func.name.as_str(), func);
            }
        }
        Interpreter {
            program,
            functions,
            globals: HashMap::new(),
            scopes: Vec::new(),
            stdout,
            stdin,
        }
    }

    /// Evaluates every top-level `Const`, then calls `Main` (which must
    /// exist and take no parameters).
    pub fn run(&mut self) -> Result<(), Diagnostic> {
        self.init_globals()?;
        let main = match self.functions.get("Main").copied() {
            Some(f) => f,
            None => {
                return Err(Diagnostic::error(
                    "No 'Main' function found",
                    self.program.span,
                ));
            }
        };
        if !main.params.is_empty() {
            return Err(Diagnostic::error(
                "'Main' must not take any parameters",
                main.span,
            ));
        }
        self.call_function(main, Vec::new())?;
        Ok(())
    }

    fn init_globals(&mut self) -> Result<(), Diagnostic> {
        // `self.program` copied out to a local first: it's already a
        // `&'a Program` (independent of `self`'s own borrow), but binding
        // it locally makes that independence obvious at the loop below
        // rather than relying on it being inferred through a `self.`
        // field access.
        let program = self.program;
        for item in &program.items {
            if let Item::Const(c) = item {
                let value = self.eval_expr(&c.value)?;
                self.globals.insert(c.name.clone(), value);
            }
        }
        Ok(())
    }

    pub(crate) fn call_function(
        &mut self,
        func: &'a FunctionDecl,
        args: Vec<Value>,
    ) -> Result<Value, Diagnostic> {
        self.push_scope();
        for (param, arg) in func.params.iter().zip(args) {
            self.declare(&param.name, arg);
        }
        let signal = self.exec_block(&func.body)?;
        self.pop_scope();
        match signal {
            Signal::Return(value) => Ok(value),
            Signal::Normal | Signal::Break | Signal::Continue => Ok(Value::Void),
        }
    }

    // --- scope management ------------------------------------------

    fn push_scope(&mut self) {
        self.scopes.push(HashMap::new());
    }

    fn pop_scope(&mut self) {
        self.scopes.pop();
    }

    /// Declares (or overwrites) `name` in the innermost scope.
    /// `kuro_semantic` has already ruled out any illegal redeclaration by
    /// the time this runs, so this never needs to report an error itself.
    fn declare(&mut self, name: &str, value: Value) {
        if let Some(scope) = self.scopes.last_mut() {
            scope.insert(name.to_string(), value);
        }
    }
}
