use std::fmt;

/// A runtime value produced by evaluating an expression.
#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Int(i64),
    Float(f64),
    Str(String),
    Bool(bool),
    Null,
    /// What a call to a function with no return type produces. Never
    /// meaningfully used by a program (`kuro_semantic` already rejects
    /// `Return value` in a function with no return type, and using such
    /// a call's result isn't valid either), but every function call
    /// needs to produce *some* `Value`.
    Void,
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Value::Int(v) => write!(f, "{v}"),
            Value::Float(v) => write!(f, "{v}"),
            Value::Str(v) => write!(f, "{v}"),
            Value::Bool(v) => write!(f, "{v}"),
            Value::Null => write!(f, "null"),
            Value::Void => Ok(()),
        }
    }
}
