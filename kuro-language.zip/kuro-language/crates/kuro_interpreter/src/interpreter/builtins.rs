use super::Interpreter;
use crate::value::Value;
use kuro_ast::Expr;
use kuro_diagnostics::Diagnostic;
use kuro_source::Span;
use std::io::{BufRead, Write};

impl<'a, W: Write, R: BufRead> Interpreter<'a, W, R> {
    /// Handles a call whose callee is `module.member(...)`, if `module`
    /// is one of the modules implemented here. `Ok(None)` means `module`
    /// isn't one of these — the caller falls back to treating it as a
    /// user-defined function/member instead.
    ///
    /// Console and Convert are implemented directly in this crate rather
    /// than through a `kuro_stdlib` crate, since none exists yet at this
    /// point in the pipeline. Moving them there later (or expanding to
    /// the rest of the stdlib) is additive, not a breaking change to
    /// anything here.
    pub(super) fn try_call_builtin(
        &mut self,
        module: &str,
        member: &str,
        args: &'a [Expr],
        span: Span,
    ) -> Result<Option<Value>, Diagnostic> {
        match module {
            "Console" => self.call_console(member, args, span).map(Some),
            "Convert" => self.call_convert(member, args, span).map(Some),
            _ => Ok(None),
        }
    }

    fn call_console(&mut self, member: &str, args: &'a [Expr], span: Span) -> Result<Value, Diagnostic> {
        match member {
            "Print" => {
                let value = self.eval_single_arg(args, span)?;
                write!(self.stdout, "{value}").ok();
                Ok(Value::Void)
            }
            "PrintLine" => {
                let value = self.eval_single_arg(args, span)?;
                writeln!(self.stdout, "{value}").ok();
                Ok(Value::Void)
            }
            "Input" => {
                let prompt = self.eval_single_arg(args, span)?;
                write!(self.stdout, "{prompt}").ok();
                self.stdout.flush().ok();
                let mut line = String::new();
                self.stdin
                    .read_line(&mut line)
                    .map_err(|e| Diagnostic::error(format!("Failed to read input: {e}"), span))?;
                let trimmed = line.trim_end_matches(['\n', '\r']).to_string();
                Ok(Value::Str(trimmed))
            }
            "Clear" => {
                self.expect_arg_count(args, 0, span)?;
                // ANSI clear-screen + move cursor home. Harmless when the
                // output isn't an interactive terminal — it just writes a
                // few bytes that a plain file or buffer will store as-is.
                write!(self.stdout, "\x1B[2J\x1B[H").ok();
                Ok(Value::Void)
            }
            other => Err(Diagnostic::error(format!("'Console' has no member '{other}'"), span)),
        }
    }

    fn call_convert(&mut self, member: &str, args: &'a [Expr], span: Span) -> Result<Value, Diagnostic> {
        match member {
            "ToInt" => {
                let value = self.eval_single_arg(args, span)?;
                Self::convert_to_int(&value, span)
            }
            "ToFloat" => {
                let value = self.eval_single_arg(args, span)?;
                Self::convert_to_float(&value, span)
            }
            "ToBool" => {
                let value = self.eval_single_arg(args, span)?;
                Self::convert_to_bool(&value, span)
            }
            "ToString" => {
                let value = self.eval_single_arg(args, span)?;
                Ok(Value::Str(value.to_string()))
            }
            other => Err(Diagnostic::error(format!("'Convert' has no member '{other}'"), span)),
        }
    }

    fn convert_to_int(value: &Value, span: Span) -> Result<Value, Diagnostic> {
        match value {
            Value::Int(v) => Ok(Value::Int(*v)),
            Value::Float(v) => Ok(Value::Int(*v as i64)),
            Value::Bool(b) => Ok(Value::Int(i64::from(*b))),
            Value::Str(s) => match s.trim().parse::<i64>() {
                Ok(v) => Ok(Value::Int(v)),
                Err(_) => Err(Diagnostic::error(format!("Cannot convert '{s}' to Int"), span)),
            },
            other => Err(Diagnostic::error(format!("Cannot convert {other} to Int"), span)),
        }
    }

    fn convert_to_float(value: &Value, span: Span) -> Result<Value, Diagnostic> {
        match value {
            Value::Int(v) => Ok(Value::Float(*v as f64)),
            Value::Float(v) => Ok(Value::Float(*v)),
            Value::Str(s) => match s.trim().parse::<f64>() {
                Ok(v) => Ok(Value::Float(v)),
                Err(_) => Err(Diagnostic::error(format!("Cannot convert '{s}' to Float"), span)),
            },
            other => Err(Diagnostic::error(format!("Cannot convert {other} to Float"), span)),
        }
    }

    fn convert_to_bool(value: &Value, span: Span) -> Result<Value, Diagnostic> {
        match value {
            Value::Bool(v) => Ok(Value::Bool(*v)),
            Value::Str(s) => match s.trim() {
                "true" => Ok(Value::Bool(true)),
                "false" => Ok(Value::Bool(false)),
                _ => Err(Diagnostic::error(format!("Cannot convert '{s}' to Bool"), span)),
            },
            other => Err(Diagnostic::error(format!("Cannot convert {other} to Bool"), span)),
        }
    }

    fn eval_single_arg(&mut self, args: &'a [Expr], span: Span) -> Result<Value, Diagnostic> {
        self.expect_arg_count(args, 1, span)?;
        self.eval_expr(&args[0])
    }

    fn expect_arg_count(&self, args: &[Expr], expected: usize, span: Span) -> Result<(), Diagnostic> {
        if args.len() != expected {
            return Err(Diagnostic::error(
                format!("Expected {expected} argument(s), found {}", args.len()),
                span,
            ));
        }
        Ok(())
    }
}
