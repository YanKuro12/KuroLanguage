use super::Interpreter;
use crate::value::Value;
use kuro_ast::{BinaryOp, Expr, ExprKind, UnaryOp};
use kuro_diagnostics::Diagnostic;
use kuro_source::Span;
use std::io::{BufRead, Write};

impl<'a, W: Write, R: BufRead> Interpreter<'a, W, R> {
    pub(crate) fn eval_expr(&mut self, expr: &'a Expr) -> Result<Value, Diagnostic> {
        match &expr.kind {
            ExprKind::IntLiteral(v) => Ok(Value::Int(*v)),
            ExprKind::FloatLiteral(v) => Ok(Value::Float(*v)),
            ExprKind::StringLiteral(v) => Ok(Value::Str(v.clone())),
            ExprKind::BoolLiteral(v) => Ok(Value::Bool(*v)),
            ExprKind::NullLiteral => Ok(Value::Null),
            ExprKind::Ident(name) => self.eval_ident(name, expr.span),
            ExprKind::Binary(left, op, right) => self.eval_binary(left, *op, right),
            ExprKind::Unary(op, operand) => self.eval_unary(*op, operand, expr.span),
            ExprKind::Call(callee, args) => self.eval_call(callee, args, expr.span),
            ExprKind::Member(object, name) => self.eval_member(object, name, expr.span),
        }
    }

    fn eval_ident(&self, name: &str, span: Span) -> Result<Value, Diagnostic> {
        for scope in self.scopes.iter().rev() {
            if let Some(value) = scope.get(name) {
                return Ok(value.clone());
            }
        }
        if let Some(value) = self.globals.get(name) {
            return Ok(value.clone());
        }
        Err(Diagnostic::error(format!("Undefined name '{name}'"), span))
    }

    fn eval_binary(&mut self, left: &'a Expr, op: BinaryOp, right: &'a Expr) -> Result<Value, Diagnostic> {
        if matches!(op, BinaryOp::And | BinaryOp::Or) {
            return self.eval_logical(left, op, right);
        }
        let left_val = self.eval_expr(left)?;
        let right_val = self.eval_expr(right)?;
        let span = left.span.to(right.span);
        match op {
            BinaryOp::Add | BinaryOp::Sub | BinaryOp::Mul | BinaryOp::Div | BinaryOp::Mod => {
                self.arith(&left_val, &right_val, op, span)
            }
            BinaryOp::Eq => Ok(Value::Bool(Self::values_equal(&left_val, &right_val))),
            BinaryOp::NotEq => Ok(Value::Bool(!Self::values_equal(&left_val, &right_val))),
            BinaryOp::Lt | BinaryOp::Gt | BinaryOp::LtEq | BinaryOp::GtEq => {
                self.compare(&left_val, &right_val, op, span)
            }
            BinaryOp::And | BinaryOp::Or => {
                unreachable!("And/Or are handled above via eval_logical for short-circuiting")
            }
        }
    }

    /// `&&`/`||` short-circuit: the right side is only evaluated when it
    /// can actually affect the result.
    fn eval_logical(&mut self, left: &'a Expr, op: BinaryOp, right: &'a Expr) -> Result<Value, Diagnostic> {
        let left_val = self.eval_expr(left)?;
        let left_bool = self.truthy(&left_val, left.span)?;
        match op {
            BinaryOp::And if !left_bool => return Ok(Value::Bool(false)),
            BinaryOp::Or if left_bool => return Ok(Value::Bool(true)),
            BinaryOp::And | BinaryOp::Or => {}
            _ => unreachable!("eval_logical is only called for And/Or"),
        }
        let right_val = self.eval_expr(right)?;
        let right_bool = self.truthy(&right_val, right.span)?;
        Ok(Value::Bool(right_bool))
    }

    fn arith(&self, left: &Value, right: &Value, op: BinaryOp, span: Span) -> Result<Value, Diagnostic> {
        match (left, right) {
            (Value::Int(a), Value::Int(b)) => Self::int_arith(*a, *b, op, span),
            (Value::Float(_), _) | (_, Value::Float(_)) => {
                let a = self.as_f64(left, span)?;
                let b = self.as_f64(right, span)?;
                Ok(Self::float_arith(a, b, op))
            }
            _ => Err(Diagnostic::error(
                format!("Cannot use this operator with {left} and {right}"),
                span,
            )),
        }
    }

    fn int_arith(a: i64, b: i64, op: BinaryOp, span: Span) -> Result<Value, Diagnostic> {
        match op {
            BinaryOp::Add => Ok(Value::Int(a + b)),
            BinaryOp::Sub => Ok(Value::Int(a - b)),
            BinaryOp::Mul => Ok(Value::Int(a * b)),
            BinaryOp::Div => {
                if b == 0 {
                    Err(Diagnostic::error("Division by zero", span))
                } else {
                    Ok(Value::Int(a / b))
                }
            }
            BinaryOp::Mod => {
                if b == 0 {
                    Err(Diagnostic::error("Division by zero", span))
                } else {
                    Ok(Value::Int(a % b))
                }
            }
            _ => unreachable!("int_arith is only called for Add/Sub/Mul/Div/Mod"),
        }
    }

    /// Unlike integer division, float division by zero isn't a KuroLanguage
    /// runtime error — it follows ordinary IEEE 754 behavior (producing
    /// infinity or NaN), the same as Rust's own `f64` division, rather
    /// than the language inventing a different rule for it.
    fn float_arith(a: f64, b: f64, op: BinaryOp) -> Value {
        match op {
            BinaryOp::Add => Value::Float(a + b),
            BinaryOp::Sub => Value::Float(a - b),
            BinaryOp::Mul => Value::Float(a * b),
            BinaryOp::Div => Value::Float(a / b),
            BinaryOp::Mod => Value::Float(a % b),
            _ => unreachable!("float_arith is only called for Add/Sub/Mul/Div/Mod"),
        }
    }

    fn compare(&self, left: &Value, right: &Value, op: BinaryOp, span: Span) -> Result<Value, Diagnostic> {
        let ordering = match (left, right) {
            (Value::Int(a), Value::Int(b)) => a.cmp(b),
            (Value::Float(_), _) | (_, Value::Float(_)) => {
                let a = self.as_f64(left, span)?;
                let b = self.as_f64(right, span)?;
                match a.partial_cmp(&b) {
                    Some(ordering) => ordering,
                    None => return Err(Diagnostic::error("Cannot compare NaN", span)),
                }
            }
            _ => {
                return Err(Diagnostic::error(
                    format!("Cannot compare {left} with {right}"),
                    span,
                ));
            }
        };
        let result = match op {
            BinaryOp::Lt => ordering == std::cmp::Ordering::Less,
            BinaryOp::Gt => ordering == std::cmp::Ordering::Greater,
            BinaryOp::LtEq => ordering != std::cmp::Ordering::Greater,
            BinaryOp::GtEq => ordering != std::cmp::Ordering::Less,
            _ => unreachable!("compare is only called for Lt/Gt/LtEq/GtEq"),
        };
        Ok(Value::Bool(result))
    }

    fn values_equal(left: &Value, right: &Value) -> bool {
        match (left, right) {
            (Value::Int(a), Value::Int(b)) => a == b,
            (Value::Float(a), Value::Float(b)) => a == b,
            (Value::Int(a), Value::Float(b)) | (Value::Float(b), Value::Int(a)) => *a as f64 == *b,
            (Value::Str(a), Value::Str(b)) => a == b,
            (Value::Bool(a), Value::Bool(b)) => a == b,
            (Value::Null, Value::Null) => true,
            _ => false,
        }
    }

    fn eval_unary(&mut self, op: UnaryOp, operand: &'a Expr, span: Span) -> Result<Value, Diagnostic> {
        let value = self.eval_expr(operand)?;
        match op {
            UnaryOp::Neg => match value {
                Value::Int(v) => Ok(Value::Int(-v)),
                Value::Float(v) => Ok(Value::Float(-v)),
                other => Err(Diagnostic::error(
                    format!("Expected a numeric value, found {other}"),
                    span,
                )),
            },
            UnaryOp::Not => {
                let b = self.truthy(&value, operand.span)?;
                Ok(Value::Bool(!b))
            }
        }
    }

    pub(crate) fn truthy(&self, value: &Value, span: Span) -> Result<bool, Diagnostic> {
        match value {
            Value::Bool(v) => Ok(*v),
            other => Err(Diagnostic::error(
                format!("Expected a Bool, found {other}"),
                span,
            )),
        }
    }

    pub(crate) fn as_f64(&self, value: &Value, span: Span) -> Result<f64, Diagnostic> {
        match value {
            Value::Int(v) => Ok(*v as f64),
            Value::Float(v) => Ok(*v),
            other => Err(Diagnostic::error(
                format!("Expected a numeric value, found {other}"),
                span,
            )),
        }
    }

    pub(crate) fn expect_int(&self, value: &Value, span: Span) -> Result<i64, Diagnostic> {
        match value {
            Value::Int(v) => Ok(*v),
            other => Err(Diagnostic::error(format!("Expected an Int, found {other}"), span)),
        }
    }

    fn eval_call(&mut self, callee: &'a Expr, args: &'a [Expr], span: Span) -> Result<Value, Diagnostic> {
        if let ExprKind::Member(object, member_name) = &callee.kind {
            if let ExprKind::Ident(module_name) = &object.kind {
                if let Some(result) = self.try_call_builtin(module_name, member_name, args, span)? {
                    return Ok(result);
                }
            }
        }
        if let ExprKind::Ident(name) = &callee.kind {
            return self.call_named_function(name, args, span);
        }
        Err(Diagnostic::error("This expression can't be called", callee.span))
    }

    fn call_named_function(&mut self, name: &str, args: &'a [Expr], span: Span) -> Result<Value, Diagnostic> {
        let mut arg_values = Vec::with_capacity(args.len());
        for arg in args {
            arg_values.push(self.eval_expr(arg)?);
        }
        let func = match self.functions.get(name).copied() {
            Some(f) => f,
            None => {
                return Err(Diagnostic::error(format!("Undefined function '{name}'"), span));
            }
        };
        self.call_function(func, arg_values)
    }

    /// Reached only when a member is accessed without being called (e.g.
    /// `Var x = Console.Print`) — there's no function-reference value in
    /// the runtime to produce, so this is a runtime error rather than a
    /// silent wrong answer.
    fn eval_member(&mut self, object: &'a Expr, _name: &str, span: Span) -> Result<Value, Diagnostic> {
        self.eval_expr(object)?;
        Err(Diagnostic::error(
            "Standard library members can only be called, not used as a value",
            span,
        ))
    }
}
