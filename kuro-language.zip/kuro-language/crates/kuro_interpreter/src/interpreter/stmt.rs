use super::{Interpreter, Signal};
use crate::value::Value;
use kuro_ast::{Block, ElseBranch, Expr, ExprKind, ForStmt, IfStmt, Stmt, WhileStmt};
use kuro_diagnostics::Diagnostic;

impl<'a, W: std::io::Write, R: std::io::BufRead> Interpreter<'a, W, R> {
    pub(crate) fn exec_block(&mut self, block: &'a Block) -> Result<Signal, Diagnostic> {
        self.push_scope();
        let result = self.exec_statements(&block.statements);
        self.pop_scope();
        result
    }

    fn exec_statements(&mut self, statements: &'a [Stmt]) -> Result<Signal, Diagnostic> {
        for stmt in statements {
            let signal = self.exec_stmt(stmt)?;
            if !matches!(signal, Signal::Normal) {
                return Ok(signal);
            }
        }
        Ok(Signal::Normal)
    }

    fn exec_stmt(&mut self, stmt: &'a Stmt) -> Result<Signal, Diagnostic> {
        match stmt {
            Stmt::VarDecl(var) => {
                let value = self.eval_expr(&var.value)?;
                self.declare(&var.name, value);
                Ok(Signal::Normal)
            }
            Stmt::ConstDecl(c) => {
                let value = self.eval_expr(&c.value)?;
                self.declare(&c.name, value);
                Ok(Signal::Normal)
            }
            Stmt::Assign(assign) => {
                let value = self.eval_expr(&assign.value)?;
                self.assign(&assign.target, value)?;
                Ok(Signal::Normal)
            }
            Stmt::Expr(expr_stmt) => {
                self.eval_expr(&expr_stmt.expr)?;
                Ok(Signal::Normal)
            }
            Stmt::If(if_stmt) => self.exec_if(if_stmt),
            Stmt::While(w) => self.exec_while(w),
            Stmt::For(f) => self.exec_for(f),
            Stmt::Foreach(_) => Err(Diagnostic::error(
                "Foreach cannot run yet: there's no collection type to iterate",
                stmt.span(),
            )),
            Stmt::Return(ret) => {
                let value = match &ret.value {
                    Some(expr) => self.eval_expr(expr)?,
                    None => Value::Void,
                };
                Ok(Signal::Return(value))
            }
            Stmt::Break(_) => Ok(Signal::Break),
            Stmt::Continue(_) => Ok(Signal::Continue),
            Stmt::Block(block) => self.exec_block(block),
        }
    }

    fn exec_if(&mut self, if_stmt: &'a IfStmt) -> Result<Signal, Diagnostic> {
        let condition = self.eval_expr(&if_stmt.condition)?;
        if self.truthy(&condition, if_stmt.condition.span)? {
            return self.exec_block(&if_stmt.then_branch);
        }
        match &if_stmt.else_branch {
            Some(ElseBranch::ElseIf(nested)) => self.exec_if(nested),
            Some(ElseBranch::Else(block)) => self.exec_block(block),
            None => Ok(Signal::Normal),
        }
    }

    fn exec_while(&mut self, w: &'a WhileStmt) -> Result<Signal, Diagnostic> {
        loop {
            let condition = self.eval_expr(&w.condition)?;
            if !self.truthy(&condition, w.condition.span)? {
                break;
            }
            let signal = self.exec_block(&w.body)?;
            match signal {
                Signal::Break => break,
                Signal::Return(_) => return Ok(signal),
                Signal::Continue | Signal::Normal => {}
            }
        }
        Ok(Signal::Normal)
    }

    /// `For binding = start To end { ... }` counts from `start` up to
    /// (but not including) `end` — an empty range if `start >= end`,
    /// consistent with how `start..end` ranges work in Rust itself.
    fn exec_for(&mut self, f: &'a ForStmt) -> Result<Signal, Diagnostic> {
        let start_value = self.eval_expr(&f.start)?;
        let end_value = self.eval_expr(&f.end)?;
        let start = self.expect_int(&start_value, f.start.span)?;
        let end = self.expect_int(&end_value, f.end.span)?;
        let mut i = start;
        while i < end {
            self.push_scope();
            self.declare(&f.binding, Value::Int(i));
            let signal = self.exec_block(&f.body)?;
            self.pop_scope();
            match signal {
                Signal::Break => break,
                Signal::Return(_) => return Ok(signal),
                Signal::Continue | Signal::Normal => {}
            }
            i += 1;
        }
        Ok(Signal::Normal)
    }

    /// Writes `value` into an already-declared binding. Only a bare
    /// identifier is meaningful right now — same scope as
    /// `kuro_semantic`'s `check_assignment_target`. `kuro_semantic` has
    /// already confirmed the target exists and isn't a `Const`, but the
    /// "undefined name" case is still handled here rather than assumed
    /// away, since this crate doesn't otherwise depend on
    /// `kuro_semantic` having run.
    fn assign(&mut self, target: &'a Expr, value: Value) -> Result<(), Diagnostic> {
        if let ExprKind::Ident(name) = &target.kind {
            for scope in self.scopes.iter_mut().rev() {
                if scope.contains_key(name) {
                    scope.insert(name.clone(), value);
                    return Ok(());
                }
            }
            if self.globals.contains_key(name) {
                self.globals.insert(name.clone(), value);
                return Ok(());
            }
            return Err(Diagnostic::error(format!("Undefined name '{name}'"), target.span));
        }
        Err(Diagnostic::error(
            "Only a plain variable name can be assigned to right now",
            target.span,
        ))
    }
}
