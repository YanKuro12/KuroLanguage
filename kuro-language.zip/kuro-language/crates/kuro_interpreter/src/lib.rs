//! Tree-walking interpreter for KuroLanguage.
//!
//! This crate depends only on `kuro_ast` for the tree it runs, and on
//! `kuro_source`/`kuro_diagnostics` for reporting runtime problems — not
//! on `kuro_lexer`, `kuro_parser`, or `kuro_semantic` (those are only
//! pulled in as dev-dependencies, for this crate's own tests). It
//! assumes `kuro_semantic` has already checked the program it's given;
//! see [`Interpreter`] for what that means for error handling here.
//!
//! `Console` and `Convert` are implemented directly in this crate (see
//! the private `interpreter::builtins` module) rather than through a
//! `kuro_stdlib` crate, since none exists yet at this point in the
//! pipeline.

mod interpreter;
mod value;

pub use interpreter::Interpreter;
pub use value::Value;

#[cfg(test)]
mod tests {
    use super::*;
    use kuro_diagnostics::Diagnostic;
    use kuro_lexer::Lexer;
    use kuro_source::SourceMap;
    use std::io::Cursor;

    /// Lexes, parses, semantically checks, then interprets `src` with
    /// `stdin` as its input, returning everything written to stdout — or
    /// the runtime error, if any stage (including execution) produced
    /// one. A lexer/parser/semantic-analysis error is treated as a test
    /// bug, not a case worth returning to the caller, since these tests
    /// are about interpretation, not the earlier stages.
    fn run_source(src: &str, stdin: &str) -> Result<String, Diagnostic> {
        let mut sources = SourceMap::new();
        let id = sources.add_file("test.kr", src);
        let (tokens, lex_diagnostics) = Lexer::new(id, src).tokenize();
        assert!(
            lex_diagnostics.is_empty(),
            "unexpected lexer errors: {lex_diagnostics:?}"
        );
        let (program, parse_diagnostics) = kuro_parser::parse(&tokens);
        assert!(
            parse_diagnostics.is_empty(),
            "unexpected parser errors: {parse_diagnostics:?}"
        );
        let semantic_diagnostics = kuro_semantic::analyze(&program);
        assert!(
            semantic_diagnostics.is_empty(),
            "unexpected semantic errors: {semantic_diagnostics:?}"
        );

        let mut stdout = Vec::new();
        {
            let stdin_reader = Cursor::new(stdin.as_bytes());
            let mut interpreter = Interpreter::new(&program, &mut stdout, stdin_reader);
            interpreter.run()?;
        }
        Ok(String::from_utf8(stdout).expect("interpreter output should be valid UTF-8"))
    }

    #[test]
    fn prints_hello_world() {
        let output =
            run_source("Func Main() {\n    Console.PrintLine(\"Hello, world!\")\n}", "").unwrap();
        assert_eq!(output, "Hello, world!\n");
    }

    #[test]
    fn arithmetic_respects_precedence() {
        let output = run_source(
            "Func Main() {\n    Console.Print(Convert.ToString(1 + 2 * 3))\n}",
            "",
        )
        .unwrap();
        assert_eq!(output, "7");
    }

    #[test]
    fn if_else_if_else_picks_the_right_branch() {
        let src = "Func Describe(n Int) {\n    If n < 0 {\n        Console.Print(\"negative\")\n    } Else If n == 0 {\n        Console.Print(\"zero\")\n    } Else {\n        Console.Print(\"positive\")\n    }\n}\nFunc Main() {\n    Describe(-1)\n    Describe(0)\n    Describe(1)\n}";
        let output = run_source(src, "").unwrap();
        assert_eq!(output, "negativezeropositive");
    }

    #[test]
    fn while_loop_with_break_and_continue() {
        let src = "Func Main() {\n    Var i = 0\n    While i < 10 {\n        i = i + 1\n        If i == 3 {\n            Continue\n        }\n        If i == 6 {\n            Break\n        }\n        Console.Print(Convert.ToString(i))\n    }\n}";
        let output = run_source(src, "").unwrap();
        assert_eq!(output, "1245");
    }

    #[test]
    fn for_loop_sums_a_range() {
        let src = "Func Main() {\n    Var total = 0\n    For i = 0 To 5 {\n        total = total + i\n    }\n    Console.Print(Convert.ToString(total))\n}";
        // 0 + 1 + 2 + 3 + 4 = 10 (5 itself is excluded, matching an
        // exclusive Rust-style range).
        let output = run_source(src, "").unwrap();
        assert_eq!(output, "10");
    }

    #[test]
    fn recursive_function_computes_factorial() {
        let src = "Func Factorial(n Int) Int {\n    If n <= 1 {\n        Return 1\n    }\n    Return n * Factorial(n - 1)\n}\nFunc Main() {\n    Console.Print(Convert.ToString(Factorial(5)))\n}";
        let output = run_source(src, "").unwrap();
        assert_eq!(output, "120");
    }

    #[test]
    fn console_input_reads_a_line_of_stdin() {
        let src =
            "Func Main() {\n    Var name = Console.Input(\"Name: \")\n    Console.PrintLine(name)\n}";
        let output = run_source(src, "Alice\n").unwrap();
        assert_eq!(output, "Name: Alice\n");
    }

    #[test]
    fn convert_round_trips_through_string() {
        let src =
            "Func Main() {\n    Var n = Convert.ToInt(\"42\")\n    Console.Print(Convert.ToString(n + 1))\n}";
        let output = run_source(src, "").unwrap();
        assert_eq!(output, "43");
    }

    #[test]
    fn division_by_zero_is_a_runtime_error_not_a_panic() {
        let result = run_source("Func Main() {\n    Console.Print(Convert.ToString(1 / 0))\n}", "");
        assert!(result.is_err());
    }

    #[test]
    fn top_level_const_is_visible_inside_functions() {
        let src = "Const Greeting = \"Hi\"\nFunc Main() {\n    Console.Print(Greeting)\n}";
        let output = run_source(src, "").unwrap();
        assert_eq!(output, "Hi");
    }

    #[test]
    fn missing_main_is_a_clean_error_not_a_panic() {
        let mut sources = SourceMap::new();
        let src = "Func NotMain() {\n}";
        let id = sources.add_file("test.kr", src);
        let (tokens, _) = Lexer::new(id, src).tokenize();
        let (program, _) = kuro_parser::parse(&tokens);
        let mut stdout = Vec::new();
        let mut interpreter =
            Interpreter::new(&program, &mut stdout, Cursor::new(&b""[..]));
        assert!(interpreter.run().is_err());
    }
}
