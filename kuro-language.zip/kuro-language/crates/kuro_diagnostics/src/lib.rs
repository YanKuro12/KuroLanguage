//! Structured compiler diagnostics for the KuroLanguage toolchain.
//!
//! Every stage that can fail — lexer, parser, semantic analysis, and later
//! stages — reports problems as a [`Diagnostic`] instead of formatting error
//! text itself, so the beginner-facing shape (file/line/column/suggestion)
//! is implemented exactly once and stays identical everywhere it's shown.

use kuro_source::{SourceMap, Span};
use std::fmt;

/// How serious a [`Diagnostic`] is.
///
/// `Error` means the file did not compile; `Warning` does not stop a build
/// — this is what lets `kuro_lint` report style or quality issues without
/// every finding being treated as a hard failure.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Severity {
    Error,
    Warning,
}

impl fmt::Display for Severity {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let name = match self {
            Severity::Error => "Error",
            Severity::Warning => "Warning",
        };
        f.write_str(name)
    }
}

/// A single reported problem: what went wrong, where, and — when possible —
/// how to fix it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Diagnostic {
    pub severity: Severity,
    pub message: String,
    pub span: Span,
    pub suggestion: Option<String>,
}

impl Diagnostic {
    pub fn error(message: impl Into<String>, span: Span) -> Self {
        Diagnostic {
            severity: Severity::Error,
            message: message.into(),
            span,
            suggestion: None,
        }
    }

    pub fn warning(message: impl Into<String>, span: Span) -> Self {
        Diagnostic {
            severity: Severity::Warning,
            message: message.into(),
            span,
            suggestion: None,
        }
    }

    /// Attaches a fix-it suggestion, e.g. `"Did you forget ')'?"`.
    #[must_use]
    pub fn with_suggestion(mut self, suggestion: impl Into<String>) -> Self {
        self.suggestion = Some(suggestion.into());
        self
    }

    /// Renders this diagnostic as beginner-facing text:
    ///
    /// ```text
    /// Error
    ///
    /// File:
    /// src/main.kr
    ///
    /// Line:
    /// 15
    ///
    /// Column:
    /// 8
    ///
    /// Expected ')'
    ///
    /// Suggestion:
    /// Did you forget ')'?
    /// ```
    ///
    /// The label/value spacing above is standardized (no blank line between
    /// a label and its value) since the spec's example had one inconsistent
    /// blank line before the suggestion text; easy to change if that was
    /// intentional. The `Suggestion` section is omitted entirely when none
    /// was attached, rather than shown empty.
    pub fn render(&self, sources: &SourceMap) -> String {
        let file = sources.get(self.span.source).name();
        let at = sources.line_col(self.span);
        let mut out = format!(
            "{}\n\nFile:\n{}\n\nLine:\n{}\n\nColumn:\n{}\n\n{}",
            self.severity, file, at.line, at.column, self.message
        );
        if let Some(suggestion) = &self.suggestion {
            out.push_str("\n\nSuggestion:\n");
            out.push_str(suggestion);
        }
        out
    }
}

/// An ordered collection of [`Diagnostic`]s accumulated while processing a
/// file, e.g. by `kuro_lexer` or `kuro_parser`.
///
/// Collecting problems instead of stopping at the first one lets a single
/// run report everything wrong at once, which is friendlier for a beginner
/// than fixing one error, recompiling, and immediately hitting the next.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Diagnostics {
    items: Vec<Diagnostic>,
}

impl Diagnostics {
    pub fn new() -> Self {
        Diagnostics { items: Vec::new() }
    }

    pub fn push(&mut self, diagnostic: Diagnostic) {
        self.items.push(diagnostic);
    }

    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    pub fn len(&self) -> usize {
        self.items.len()
    }

    pub fn has_errors(&self) -> bool {
        self.items.iter().any(|d| d.severity == Severity::Error)
    }

    pub fn iter(&self) -> impl Iterator<Item = &Diagnostic> {
        self.items.iter()
    }

    /// Renders every diagnostic in order, separated by a blank line.
    pub fn render(&self, sources: &SourceMap) -> String {
        self.items
            .iter()
            .map(|d| d.render(sources))
            .collect::<Vec<_>>()
            .join("\n\n")
    }
}

impl IntoIterator for Diagnostics {
    type Item = Diagnostic;
    type IntoIter = std::vec::IntoIter<Diagnostic>;

    fn into_iter(self) -> Self::IntoIter {
        self.items.into_iter()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_map() -> (SourceMap, Span) {
        let mut sources = SourceMap::new();
        let id = sources.add_file("src/main.kr", "Func Main(\n");
        // Points at the newline right after the unclosed '(' on line 1, so
        // "Expected ')'" reads as pointing right where the paren should be.
        let span = Span::new(id, 10, 11);
        (sources, span)
    }

    #[test]
    fn renders_with_suggestion() {
        let (sources, span) = sample_map();
        let diagnostic =
            Diagnostic::error("Expected ')'", span).with_suggestion("Did you forget ')'?");
        let rendered = diagnostic.render(&sources);
        assert_eq!(
            rendered,
            "Error\n\nFile:\nsrc/main.kr\n\nLine:\n1\n\nColumn:\n11\n\nExpected ')'\n\nSuggestion:\nDid you forget ')'?"
        );
    }

    #[test]
    fn renders_without_suggestion() {
        let (sources, span) = sample_map();
        let diagnostic = Diagnostic::warning("Unused variable 'x'", span);
        let rendered = diagnostic.render(&sources);
        assert!(rendered.starts_with("Warning\n\nFile:\nsrc/main.kr"));
        assert!(!rendered.contains("Suggestion"));
    }

    #[test]
    fn has_errors_ignores_warnings_only() {
        let (_, span) = sample_map();
        let mut diagnostics = Diagnostics::new();
        diagnostics.push(Diagnostic::warning("Unused variable 'x'", span));
        assert!(!diagnostics.has_errors());
        diagnostics.push(Diagnostic::error("Expected ')'", span));
        assert!(diagnostics.has_errors());
        assert_eq!(diagnostics.len(), 2);
    }
}
